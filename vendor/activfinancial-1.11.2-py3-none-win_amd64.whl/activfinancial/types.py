import binascii
import ctypes
import datetime
import functools

from . import _c_lib
from . import constants

class Handle:
	def __init__(self, session, value):
		self.session = session
		self.value = value

	def __bool__(self):
		return self.value != constants.HANDLE_UNDEFINED

	def __int__(self):
		return self.value

	def close(self):
		if self:
			value = self.value
			self.value = constants.HANDLE_UNDEFINED
			self.session.close_handle(value)

class Context:
	def __init__(self, session, handle_value, user_data):
		self.handle = Handle(session, handle_value)
		self.user_data = user_data

	@property
	def session(self):
		return self.handle.session

class SnapshotMessage:
	def __init__(self, msg, fields):
		self.data_source_id = msg.data_source_id
		self.symbol         = msg.symbol.decode()
		self.symbology_id = msg.symbology_id
		self.permission_id = msg.permission_id
		self.update_id = msg.update_id
		self.timestamp = msg.timestamp[0].time() if msg.timestamp else None
		self.complete = msg.is_complete
		self.fields = fields

class SnapshotFailureMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbol         = msg.symbol.decode()
		self.symbology_id = msg.symbology_id
		self.permission_id = msg.permission_id
		self.status_code = msg.status_code
		self.complete = msg.is_complete

class RefreshMessage:
	def __init__(self, msg, fields):
		self.data_source_id = msg.data_source_id
		self.symbol         = msg.symbol.decode()
		self.symbology_id = msg.symbology_id
		self.topic_type = msg.topic_type
		self.permission_id = msg.permission_id
		self.update_id = msg.update_id

		if msg.map_key_length > 0:
			self.map_key = bytes(msg.map_key_buffer[0:msg.map_key_length])
		else:
			self.map_key = None

		self.topic_subscription_state = msg.topic_subscription_state
		self.gateway_timestamp = msg.gateway_timestamp[0].time() if msg.gateway_timestamp else None
		self.api_timestamp = msg.api_timestamp[0].time() if msg.api_timestamp else None
		self.fields = fields

class UpdateMessage:
	def __init__(self, msg, fields):
		self.data_source_id = msg.data_source_id
		self.symbol         = msg.symbol.decode()
		self.symbology_id = msg.symbology_id
		self.topic_type = msg.topic_type
		self.permission_id = msg.permission_id
		self.update_id = msg.update_id
		self.event_type = msg.event_type
		self.update_type = msg.update_type

		if msg.map_key_length > 0:
			self.map_key = bytes(msg.map_key_buffer[0:msg.map_key_length])
		else:
			self.map_key = None

		self.topic_subscription_state = msg.topic_subscription_state
		self.source_id = msg.source_id[0] if msg.source_id else None
		self.sequence_number = msg.sequence_number[0] if msg.sequence_number else None
		self.exchange_transaction_timestamp = msg.exchange_transaction_timestamp[0].time() if msg.exchange_transaction_timestamp else None
		self.source_timestamp = msg.source_timestamp[0].time() if msg.source_timestamp else None
		self.gateway_timestamp = msg.gateway_timestamp[0].time() if msg.gateway_timestamp else None
		self.api_timestamp = msg.api_timestamp[0].time() if msg.api_timestamp else None
		self.fields = fields

class TopicStatusMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbol         = msg.symbol.decode()
		self.symbology_id = msg.symbology_id
		self.topic_type = msg.topic_type
		self.topic_subscription_state = msg.topic_subscription_state

class SubscriptionStatusMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbology_id = msg.symbology_id
		self.request = msg.request.decode()
		self.state = msg.state
		self.status_code = msg.status_code if constants.STATUS_CODE_SUCCESS != msg.status_code else None
	
	def is_pending(self):
		return self.state == constants.SUBSCRIPTION_STATE_PENDING

	def is_complete(self):
		return self.state == constants.SUBSCRIPTION_STATE_COMPLETE

	def is_error(self):
		return self.state == constants.SUBSCRIPTION_STATE_ERROR

	def is_failure(self):
		return self.state == constants.SUBSCRIPTION_STATE_FAILURE

class QueryAddMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbol = msg.symbol.decode()
		self.topic_type = msg.topic_type
		self.table_number = msg.table_number

class QueryRemoveMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbol = msg.symbol.decode()

class QueryStatusMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.query = msg.query.decode()
		self.state = msg.state
		self.status_code = msg.status_code if constants.STATUS_CODE_SUCCESS != msg.status_code else None
	
	def is_pending(self):
		return self.state == constants.QUERY_STATE_PENDING

	def is_complete(self):
		return self.state == constants.QUERY_STATE_COMPLETE

	def is_error(self):
		return self.state == constants.QUERY_STATE_ERROR

	def is_failure(self):
		return self.state == constants.QUERY_STATE_FAILURE

class AtomicSnapshotResult:
	def __init__(self, msg, fields):
		self.symbol = msg.symbol.decode()
		self.fields = fields

class DictionaryEntry:
	def __init__(self, msg):
		self.name = msg.name.decode()
		self.type = msg.type

class Field:
	def __init__(self, value, field_type, does_update_last):
		self.field_type = field_type
		self.does_update_last = does_update_last

		if not (value is None):
			self.value = _c_lib.decode_field_value(field_type, value)
		else:
			self.value = None

	def is_defined(self):
		return not (self.value is None)

	def to_native(self):
		if hasattr(self.value, 'to_native'):
			return self.value.to_native()
		else:
			return self.value

	def __str__(self):
		if isinstance(self.value, bytes):
			return f"0x{binascii.hexlify(self.value).decode()}"
		else:
			return str(self.value)

class TimeSeriesMessage:
	def __init__(self, msg, fields):
		self.data_source_id = msg.data_source_id
		self.symbology_id   = msg.symbology_id
		self.symbol         = msg.symbol.decode()
		self.permission_id  = msg.permission_id
		self.type           = msg.type
		self.complete       = msg.is_complete
		self.fields         = fields

class TimeSeriesFailureMessage:
	def __init__(self, msg):
		self.data_source_id = msg.data_source_id
		self.symbology_id   = msg.symbology_id
		self.symbol         = msg.symbol.decode()
		self.permission_id  = msg.permission_id
		self.status_code    = msg.status_code
		self.complete       = msg.is_complete
