from . import _status_code_strings
from . import market_data
from . import types

def status_code_to_string(status_code):
	if status_code in _status_code_strings._string_map:
		return _status_code_strings._string_map[status_code]

	return f"status code {status_code}"

def _snapshot_msg_list_to_pandas_fields(msg_list, to_native):
	index = []
	cols = {}

	for msg in msg_list:
		for (id, field) in msg.fields.items():
			col = cols.setdefault(id, [])

			# Pad list out with None as needed.
			if len(col) < len(index):
				col += [None] * (len(index) - len(col))
			
			if to_native:
				col.append(field.to_native())
			else:
				col.append(field.value)
		
		index.append(msg.symbol)

	return (index, cols)

def _snapshot_failure_msg_list_to_pandas_fields(msg_list):
	symbols = []
	errors = []
	permission_ids = []

	for msg in msg_list:
		symbols.append(msg.symbol)
		errors.append(status_code_to_string(msg.status_code))
		permission_ids.append(msg.permission_id)

	return (None, { 'Symbol': symbols, 'StatusCode': errors, 'PermissionId': permission_ids })

def _query_add_msg_list_to_pandas_fields(msg_list):
	symbols = []
	for msg in msg_list:
		symbols.append(msg.symbol)

	return (None, { 'Symbol': symbols })

def _time_series_msg_list_to_pandas_fields(msg_list, to_native):
	index = []
	cols = {}

	if market_data.FID_DATE_TIME in msg_list[0].fields:
		index_fid = market_data.FID_DATE_TIME
		index_name = 'DateTime'
	else:
		index_fid = market_data.FID_DATE
		index_name = 'Date'

	for msg in msg_list:
		for (id, field) in msg.fields.items():
			if id != index_fid:
				col = cols.setdefault(id, [])

				# Pad list out with None as needed.
				if len(col) < len(index):
					col += [None] * (len(index) - len(col))
				
				if to_native:
					col.append(field.to_native())
				else:
					col.append(field.value)
		
		index_field = msg.fields.get(index_fid)

		if index_field is None:
			raise RuntimeError(f'time series message missing key field id {index_fid}')
		
		if to_native:
			index.append(index_field.to_native())
		else:
			index.append(index_field.value)

	return (index, cols, index_name)

def _to_pandas(metadata, result, field_names, to_native):
	import pandas

	if type(result) == list:
		msg_list = result
	else:
		msg_list = [ result ]
	
	if len(msg_list) == 0:
		return None

	if type(msg_list[0]) == types.SnapshotMessage:
		(index, cols) = _snapshot_msg_list_to_pandas_fields(msg_list, to_native)
		index_name = 'Symbol'
	elif type(msg_list[0]) == types.SnapshotFailureMessage:
		(index, cols) = _snapshot_failure_msg_list_to_pandas_fields(msg_list)
		index_name = 'Symbol'
	elif type(msg_list[0]) == types.QueryAddMessage:
		(index, cols) = _query_add_msg_list_to_pandas_fields(msg_list)
	elif type(msg_list[0]) == types.TimeSeriesMessage:
		(index, cols, index_name) = _time_series_msg_list_to_pandas_fields(msg_list, to_native)
	else:
		raise RuntimeError(f'conversion of {type(msg_list[0])} is not supported')
	
	data_source = msg_list[0].data_source_id

	if field_names:
		for key in list(cols.keys()):
			if type(key) == int:
				cols[metadata.get_field_name(data_source, key)] = cols.pop(key)

	# Pad out all columns to the same length.
	if not (index is None):
		for col in cols.values():
			if len(col) < len(index):
				col += [None] * (len(index) - len(col))

	df = pandas.DataFrame(cols, index=index)

	if not (index is None):
		df.index.name = index_name

	return df
