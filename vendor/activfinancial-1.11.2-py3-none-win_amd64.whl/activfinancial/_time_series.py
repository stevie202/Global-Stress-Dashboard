class Tick:
    FILTER_NONE = 0                          # No filter.
    FILTER_REGULAR_TRADES = 1                # Regular trades only.
    FILTER_NON_REGULAR_TRADES = 2            # Non-regular trades only.
    FILTER_TRADES = 3                        # Regular and non-regular trades.
    FILTER_TRADE_CANCELS_AND_CORRECTIONS = 4 # Trade cancels and corrections.
    FILTER_ALL_TRADES = 5                    # All trades. This is a combination of regular and non-regular trades, and trade cancels and corrections.
    FILTER_LULD_AND_TRADING_STATUS = 6       # Limit high/low (LULD), and trading status.
    FILTER_BIDS = 7                          # Bids only.
    FILTER_ASKS = 8                          # Asks only.
    FILTER_QUOTES = 9                        # Bids and asks.
    FILTER_QUOTES_AND_TRADES = 10            # All quotes and all trades including regular and non-regular trades, and trade cancel and corrections.

    _FILTER_LOOKUP_MAP = {
        "none" :                         FILTER_NONE,
        "regular-trades" :               FILTER_REGULAR_TRADES,
        "non-regular-trades":            FILTER_NON_REGULAR_TRADES,
        "trades":                        FILTER_TRADES,
        "trade-cancels-and-corrections": FILTER_TRADE_CANCELS_AND_CORRECTIONS,
        "all-trades":                    FILTER_ALL_TRADES,
        "luld-and-trading-status":       FILTER_LULD_AND_TRADING_STATUS,
        "bids":                          FILTER_BIDS,
        "asks":                          FILTER_ASKS,
        "quotes":                        FILTER_QUOTES,
        "quotes-and-trades":             FILTER_QUOTES_AND_TRADES }

    filters = list(_FILTER_LOOKUP_MAP.keys())

    @classmethod
    def string_to_filter(cls, string):
        if string in cls._FILTER_LOOKUP_MAP:
            return cls._FILTER_LOOKUP_MAP[string]
        else:
            raise RuntimeError(f"invalid filter '{string}' - must be one of {cls.filters}")

class IntradayBar:
    INTERVAL_ONE_MINUTE = 1      # One minute bars.
    INTERVAL_TWO_MINUTE = 2      # Two minute bars.
    INTERVAL_FIVE_MINUTE = 5     # Five minute bars.
    INTERVAL_TEN_MINUTE = 10     # Ten minute bars.
    INTERVAL_FIFTEEN_MINUTE = 15 # Fifteen minute bars.
    INTERVAL_THIRTY_MINUTE = 30  # Thirty minute bars.
    INTERVAL_SIXTY_MINUTE = 60   # Sixty minute bars.

    FILTER_NONE = 0           # No filter.
    FILTER_REGULAR_TRADES = 1 # Only bars with regular trades. Excludes bars with no regular trade.
    FILTER_OHLC_BARS = 2      # All bars with open/high/low/close values. Exclude bars with only cumulative values (with ONLY trades that do not update the last price).

    _INTERVAL_LOOKUP_MAP = {
        "1m" : INTERVAL_ONE_MINUTE,
        "2m" : INTERVAL_TWO_MINUTE,
        "5m" : INTERVAL_FIVE_MINUTE,
        "10m": INTERVAL_TEN_MINUTE,
        "15m": INTERVAL_FIFTEEN_MINUTE,
        "30m": INTERVAL_THIRTY_MINUTE,
        "60m": INTERVAL_SIXTY_MINUTE }

    _FILTER_LOOKUP_MAP = {
        "none" :           FILTER_NONE,
        "regular-trades" : FILTER_REGULAR_TRADES,
        "ohlc-bars":       FILTER_OHLC_BARS }

    intervals = list(_INTERVAL_LOOKUP_MAP.keys())
    filters = list(_FILTER_LOOKUP_MAP.keys())

    @classmethod
    def string_to_interval(cls, string):
        if string in cls._INTERVAL_LOOKUP_MAP:
            return cls._INTERVAL_LOOKUP_MAP[string]
        else:
            raise RuntimeError(f"invalid interval '{string}' - must be one of {cls.intervals}")

    @classmethod
    def string_to_filter(cls, string):
        if string in cls._FILTER_LOOKUP_MAP:
            return cls._FILTER_LOOKUP_MAP[string]
        else:
            raise RuntimeError(f"invalid filter '{string}' - must be one of {cls.filters}")

class HistoryBar:
    INTERVAL_DAILY = 0	 # Daily bars.
    INTERVAL_WEEKLY = 1  # Weekly bars.
    INTERVAL_MONTHLY = 2 # Monthly bars.

    _INTERVAL_LOOKUP_MAP = {
        "daily"   : INTERVAL_DAILY,
        "weekly"  : INTERVAL_WEEKLY,
        "monthly" : INTERVAL_MONTHLY }

    intervals = list(_INTERVAL_LOOKUP_MAP.keys())

    @classmethod
    def string_to_interval(cls, string):
        if string in cls._INTERVAL_LOOKUP_MAP:
            return cls._INTERVAL_LOOKUP_MAP[string]
        else:
            raise RuntimeError(f"invalid interval '{string}' - must be one of {cls.intervals}")
