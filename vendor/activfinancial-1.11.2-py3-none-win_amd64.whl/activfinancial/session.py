from . import constants
from . import field_types
from . import metadata
from . import types
from . import utils
from . import _c_lib
from . import _session_impl
from . import _time_series
from . import _utils

import copy
import ctypes

class Session:
	'''The Session class provides the connection and API to the platform.

	Uses DATA_SOURCE_ACTIV by default, this can be overridden on individual calls or by setting FID_DATA_SOURCE.
	
	Parameters
	----------

	parameters : dict, optional
		Dictionary of session parameters, default empty.
	handler : object, optional
		Handler to receive session notification callbacks.
	dll_path : str, optional
		Explicit path to the C++ libraries. The path is discovered automatically if not specified.
	
	Raises
	------

	RuntimeError
		Failure to load libraries or invalid parameter specified.
	'''

	def __init__(self, parameters={}, handler=None, dll_path=None):
		
		self._impl = _session_impl.SessionImpl(self, parameters, handler, dll_path)
		self.parameters = copy.deepcopy(parameters)

		if constants.FID_DATA_SOURCE not in self.parameters:
			self.parameters[constants.FID_DATA_SOURCE] = constants.DATA_SOURCE_ACTIV
		
		if constants.FID_SYMBOLOGY not in self.parameters:
			self.parameters[constants.FID_SYMBOLOGY] = constants.SYMBOLOGY_NATIVE

		self.default_data_source_id = self.parameters[constants.FID_DATA_SOURCE]
		self.default_symbology_id = self.parameters[constants.FID_SYMBOLOGY]
		self.metadata = metadata.Metadata()
		self._snapshot_parameters_map = {}

		# _on_wakeup allows NotebookSession to add a wakeup callback.
		self._on_wakeup = lambda should_connect: None

	def __del__(self):
		if hasattr(self, '_snapshot_parameters_map'):
			for handle in self._snapshot_parameters_map.values():
				self.close_handle(handle)

	def get_state(self):
		'''Get the state of the session.
		
		Returns
		-------

		int
			Status of the session. See constants.session_states for possible values.

			Use constants.session_state_to_string() to convert to a string representation.
		
		Raises
		------
		RuntimeError
			Session is not initialized.
		'''

		self._on_wakeup(False)
		return self._impl.lib.activ_session_get_state(self._impl.session_context)

	def connect(self, parameters={}, timeout=5000):
		'''Connect to the platform synchronously.
		
		Parameters
		----------

		parameters : dict, optional
			Connection parameters:

			    FID_HOST
			    FID_USER_ID
			    FID_PASSWORD
			
			If not provided the session parameters are used.
		
		timeout : int, optional
			Timeout in milliseconds, default 5000.
		
		Raises
		------

		RuntimeError
			On connection failure.
		'''

		self._on_wakeup(False)

		metadata_msg = _session_impl.POINTER(_session_impl.C_MetadataMessage)()
		status_code = self._impl.lib.activ_session_connect(self._impl.session_context, _utils.DictToFieldMapString(parameters).encode(), timeout, _session_impl.byref(metadata_msg))

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(f'{self._get_error()} (connecting to {self.get_parameters()[constants.FID_HOST]})')

		self.metadata._update(metadata_msg[0])

		self._check_publish_mode()

	def async_connect(self, parameters={}):
		'''Connect to the platform asynchronously.
		
		Parameters
		----------

		parameters : dict, optional
			Connection parameters:

			    FID_HOST
			    FID_USER_ID
			    FID_PASSWORD
			
			If not provided the session parameters are used.
		
		Raises
		------

		RuntimeError
			On failure to initiate the connection such as an invalid parameter.
		'''

		self._on_wakeup(False)

		status_code = self._impl.lib.activ_session_async_connect(self._impl.session_context, _utils.DictToFieldMapString(parameters).encode())

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(f'failed to connect {self.get_parameters()[constants.FID_HOST]} - {utils.status_code_to_string(status_code)}')

	def disconnect(self):
		'''Disconnect from the platform.
		
		Raises
		------
		
		RuntimeError
			On failure to disconnect due to already being disconnected.'''
		self._on_wakeup(False)
		self._impl.lib.activ_session_disconnect(self._impl.session_context)

	def get_parameters(self):
		'''Get the session parameters.
		
		Returns
		-------
		
		dict
			Dictionary of session parameters keyed on field id.
		
		Raises
		------
		
		RuntimeError
			On failure to fetch parameters.'''
		self._on_wakeup(True)

		host = _session_impl.c_char_p()
		user_id = _session_impl.c_char_p()
		password = _session_impl.c_char_p()

		status_code = self._impl.lib.activ_session_get_parameters(self._impl.session_context,
			_session_impl.byref(host), _session_impl.byref(user_id), _session_impl.byref(password))

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(self._get_error())

		return {
			constants.FID_HOST: host.value.decode(),
			constants.FID_USER_ID: user_id.value.decode(),
			constants.FID_PASSWORD: password.value.decode() }

	def process(self):
		'''Process the session for a brief period.
		
		Returns
		-------
		int
			STATUS_CODE_SUCCESS: session processed successfully.
			STATUS_CODE_EXIT: returned when shutdown() has been called.
			
		Raises
		------
		RuntimeError
			Error processing session.'''

		self._on_wakeup(True)
		return self._impl.lib.activ_session_process(self._impl.session_context)

	def run(self):
		'''Run the session message loop until shutdown() is called.
		
		Raises
		------
		RuntimeError
			Error running the session.'''

		self._on_wakeup(True)
		while constants.STATUS_CODE_EXIT != self.process():
			pass

	@classmethod
	def post_user_message(cls, session, message):
		'''Post a user message to the session.
		
		This method is thread-safe. Allows posting a message from any thread to the thread processing the Session.
		
		The handler on the session will receive an on_session_user_message() callback containing the message.
		See the post_user_message sample.

		Parameters
		----------
		session : Session
			The Session to post the message to.
		message : bytes
			Message to pass to the session.

		Raises
		------
		RuntimeError
			Error posting message to session.
		'''
		if not isinstance(message, bytes):
			raise RuntimeError('message must be of type bytes')
		
		status_code = session._impl.lib.activ_session_post_user_message(session._impl.session_context, message, len(message))

		if constants.STATUS_CODE_SUCCESS != status_code:
			raise RuntimeError(session._get_error())

	@classmethod
	def post_task(cls, session, task):
		'''Post a task to the session thread.
		
		This method is thread-safe. Allows posting a task from any thread to the thread processing the Session.

		Parameters
		----------
		session : Session
			The Session to execute the task on.
		task : callable
			The task to execute on the session thread.
		
		Raises
		------
		RuntimeError
			Error posting message to session.
		'''

		if not callable(task):
			raise RuntimeError(f'object {task} not callable')

		session._impl.task_queue.append(task)

		status_code = session._impl.lib.activ_session_post_task(session._impl.session_context)

		if status_code != constants.STATUS_CODE_SUCCESS:
			session._impl.task_queue.remove(task)
			raise RuntimeError(session._get_error())

	@classmethod
	def shutdown(cls, session):
		'''Shutdown the session.
		
		This method is thread-safe.
		
		Raises
		------
		RuntimeError
			Error shutting down the session.'''

		status_code = session._impl.lib.activ_session_shutdown(session._impl.session_context)

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(session._get_error())

	def close_handle(self, handle):
		'''Close a free raw handle (that is not being managed by the Handle class).

		Best practice is to use the Handle.close method.
		
		Parameters
		----------
		handle : int
			Raw handle to close.
		
		Raises
		------
		RuntimeError
			Error closing the handle, such as an invalid handle value.'''

		self._on_wakeup(True)

		handle_value = int(handle)
		if handle_value in self._impl.handler_map:
			self._impl.handler_map.pop(handle_value)

		if hasattr(self._impl ,'session_context'):
			self._impl.lib.activ_session_close_handle(self._impl.session_context, handle_value)

	def register_snapshot_parameters(self, parameters):
		'''Register snapshot parameters.
		
		See Appendix 2 of the ActivOneApi documentation for parameter details.
		
		Parameters
		----------
		parameters : dict
			Dictionary of (field id, value) pairs holding the parameters.
		
		Returns
		-------
		Handle
			Handle for the parameters.
		
		Raises
		------
		RuntimeError
			Error registering snapshot parameters.
		'''
		
		self._on_wakeup(True)

		string = _utils.DictToFieldMapString(parameters)
		handle = _session_impl.c_uint64()
		status_code = self._impl.lib.activ_session_register_snapshot_parameters(self._impl.session_context, string.encode(), _session_impl.byref(handle))

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(self._get_error())

		return types.Handle(self, handle.value)

	def snapshot(self, symbol, handler=None, symbology_id=None, parameters=None,
			  	 user_data=None, data_source_id=None, timeout=None, fields=None):

		'''Request a snapshot for a symbol.
		
		The method is synchronous by default and the result of the request is returned immediately.
		
		If a handler is provided, then the request is asynchronous and the result is received through the handler callbacks.

		The parameters and fields arguments cannot be used together.
		
		Parameters
		----------
		symbol : str
			Symbol to snapshot.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		symbology_id : int, optional
			Symbology of the symbol, uses the session default if not specified.
		parameters : Handle, optional
			Snapshot parameters Handle to use with this request (see register_snapshot_parameters()).
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
			Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		fields : list, optional
			List of field ids or names to request.
			When using field names, the dictionary for the data source must be available.
		
		Returns
		-------
		SnapshotMessage
			By default, returns a SnapshotMessage retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the snapshot.
		'''
		
		self._on_wakeup(True)

		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		symbology_id = symbology_id or self.default_symbology_id
		parameters = parameters or constants.HANDLE_UNDEFINED

		if fields is not None:
			if parameters != constants.HANDLE_UNDEFINED:
				raise RuntimeError('parameters and fields cannot be specified together')
			
			parameters = self._get_snapshot_parameters(data_source_id, fields)

		if handler is None:
			msg = _session_impl.C_SnapshotMessage()
			status_code = self._impl.lib.activ_session_sync_snapshot(self._impl.session_context, data_source_id,
														             symbology_id, symbol.encode(), int(parameters),
																	 timeout or 0xffffffff, _session_impl.byref(msg))

			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())

			field_dict = {}
			for i in range(0, msg.number_of_fields):
				field = msg.fields[i]
				field_dict[field.field_id] = types.Field(field.value, field.field_type, field.does_update_last)
			
			return types.SnapshotMessage(msg, field_dict)

		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')
	
			handle = self._impl.lib.activ_session_snapshot(self._impl.session_context, data_source_id,
														   symbology_id, symbol.encode(), int(parameters))

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def register_subscription_parameters(self, parameters):
		'''Register subscription parameters.
		
		See Appendix 3 of the ActivOneApi documentation for parameter details.
		
		Parameters
		----------
		parameters : dict
			Dictionary of (field id, value) pairs holding the parameters.
		
		Returns
		-------
		Handle
			Handle for the parameters.
		
		Raises
		------
		RuntimeError
			Error registering subscription parameters.
		'''

		self._on_wakeup(True)

		string = _utils.DictToFieldMapString(parameters)
		handle = _session_impl.c_uint64()
		status_code = self._impl.lib.activ_session_register_subscription_parameters(self._impl.session_context, string.encode(), _session_impl.byref(handle))

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(self._get_error())

		return types.Handle(self, handle.value)

	def subscribe(self, symbol, handler, symbology_id=None, parameters=None,
			   	  user_data=None, data_source_id=None):
		
		'''Subscribe to a symbol.
		
		Parameters
		----------
		symbol : str
			Symbol to subscribe to.
		handler : object, optional
			Handler to receive messages through asynchronous callbacks.
		symbology_id : int, optional
			Symbology of the symbol, uses the session default if not specified.
		parameters : int or Handle, optional
			Subscription parameters Handle to use with this request (see register_subscription_parameters()).
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		
		Returns
		-------
		Handle
			The Handle of this request.
		
		Raises
		------
		RuntimeError
			Error requesting the subscription.
		'''

		self._on_wakeup(True)

		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		symbology_id = symbology_id or self.default_symbology_id
		parameters = parameters or constants.HANDLE_UNDEFINED

		handle = self._impl.lib.activ_session_subscribe(self._impl.session_context, data_source_id,
												  		symbology_id, symbol.encode(), int(parameters))

		if constants.HANDLE_UNDEFINED == handle:
			raise RuntimeError(self._get_error())

		if not hasattr(handler, 'on_subscription_status') and hasattr(handler, 'on_subscription_error'):
			handler = _utils.DeprecatedSubscriptionHandler(handler)

		self._impl.handler_map[handle] = (handler, user_data)
		return types.Handle(self, handle)

	def query(self, query, handler=None, user_data=None, data_source_id=None, timeout=None):
		'''Request a query for topics.
		
		The method is synchronous by default and the results of the request are returned immediately.
		
		If a handler is provided, then the request is asynchronous and results are received through the handler callbacks.
		Asynchronous queries remain open until the handle is closed, watching for changes to the result set.

		Parameters
		----------
		query : str
			The tag expression query.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context. Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		
		Returns
		-------
		list of QueryAddMessage
			By default, returns a list of QueryAddMessage objects retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the query.
		'''
		
		self._on_wakeup(True)

		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id

		if handler is None:
			msg_list = _session_impl.POINTER(_session_impl.C_QueryAddMessage)()
			msg_count = _session_impl.c_uint32(0)

			status_code = self._impl.lib.activ_session_sync_query(self._impl.session_context, data_source_id, query.encode(),
														 		  timeout or 0xffffffff,
																  _session_impl.byref(msg_list), _session_impl.byref(msg_count))

			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())

			# Convert the results to a list of QueryAddMessage objects.
			result = []
			for i in range(0, msg_count.value):
				result.append(types.QueryAddMessage(msg_list[i]))

			return result
		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')

			handle = self._impl.lib.activ_session_query(self._impl.session_context, data_source_id, query.encode())

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			if not hasattr(handler, 'on_query_status') and hasattr(handler, 'on_query_start'):
				handler = _utils.DeprecatedQueryHandler(handler)

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def publish(self, symbol, fields, table=constants.TABLE_NO_UNDEFINED, permission_id=constants.PERMISSION_ID_NONE,
			 event_type=constants.EVENT_TYPE_NONE, flags=constants.PUBLISH_FLAG_NONE):

		'''Publish an update to a cache on the platform.
		
		The session must have been configured with push mode publishing to use this method.
		
		Parameters
		----------
		
		symbol : str
			The symbol the update is for.
		fields : dict of (field id, value)
			The field data to publish.
		table : int, optional
			The table number to update must match the schema of the cache where applicable.
		permission_id : int, optional
			The permission id to use, PERMISSION_ID_NONE allows access to all users.
		event_type : int, optional
			The type of event.
		flags : int, optional
			Flags to control cache behavior (see constants.publish_flags).
		
		Raises
		------
		RuntimeError
			Error publishing the update.
		'''

		self._on_wakeup(True)
		
		(field_data_list, cached_values) = field_types._build_field_data(self, fields)
		field_data_array = (_c_lib.C_FieldData * len(field_data_list))(*field_data_list)

		status_code = self._impl.lib.activ_session_publish(
			self._impl.session_context, symbol.encode(), field_data_array,
			len(field_data_array), table, permission_id, event_type, flags)

		if status_code != constants.STATUS_CODE_SUCCESS:
			raise RuntimeError(self._get_error())

	def query_subscribe(self, query, handler=None, parameters=None, user_data=None,
					    data_source_id=None):
		'''Subscribe to the result of a query.
		
		Parameters
		----------
		query : str
			The query to subscribe to.
		handler : object, optional
			Handler to receive messages through asynchronous callbacks.
		parameters : int or Handle, optional
			Subscription parameters Handle to use with this request (see register_subscription_parameters()).
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		
		Returns
		-------
		Handle
			The Handle of this request.
		
		Raises
		------
		RuntimeError
			Error requesting the subscription.'''

		self._on_wakeup(True)

		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		parameters = parameters or constants.HANDLE_UNDEFINED

		handle = self._impl.lib.activ_session_query_subscribe(self._impl.session_context, data_source_id,
															  query.encode(), parameters)

		if constants.HANDLE_UNDEFINED == handle:
			raise RuntimeError(self._get_error())

		if not hasattr(handler, 'on_subscription_status') and hasattr(handler, 'on_subscription_error'):
			handler = _utils.DeprecatedSubscriptionHandler(handler)

		self._impl.handler_map[handle] = (handler, user_data)
		return types.Handle(self, handle)

	def query_snapshot(self, query, handler=None, parameters=None, user_data=None,
					   data_source_id=None, timeout=None, fields=None):
		'''Snapshot the results of a query.
		
		The method is synchronous by default and the results of the request are returned immediately.
		
		If a handler is provided, then the request is asynchronous and results are received through the handler callbacks.

		The parameters and fields arguments cannot be used together.
		
		Parameters
		----------
		query : str
			The query providing the symbols to snapshot.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		parameters : Handle, optional
			Snapshot parameters Handle to use with this request (see register_snapshot_parameters()).
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
			Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		fields : list, optional
			List of field ids or names to request.
			When using field names, the dictionary for the data source must be available.
		
		Returns
		-------
		(list of SnapshotMessage, list of SnapshotFailureMessage)
			By default, returns successful snapshots and failures retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the snapshot.
		'''		

		self._on_wakeup(True)
		
		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		parameters = parameters or constants.HANDLE_UNDEFINED

		if fields is not None:
			if parameters != constants.HANDLE_UNDEFINED:
				raise RuntimeError('parameters and fields cannot be specified together')
			
			parameters = self._get_snapshot_parameters(data_source_id, fields)

		if handler is None:
			msg_list = list()
			failure_msg_list = list()

			callback = _c_lib.C_SyncSnapshotMessageCallback(
				lambda msg_pointer : self._impl.sync_snapshot_message_callback(msg_list, msg_pointer))
			failure_callback = _c_lib.C_SyncSnapshotFailureMessageCallback(
				lambda msg_pointer : self._impl.sync_snapshot_failure_message_callback(failure_msg_list, msg_pointer))

			status_code = self._impl.lib.activ_session_sync_query_snapshot(self._impl.session_context, data_source_id,
																  		   query.encode(), int(parameters), timeout or 0xffffffff,
																		   callback, failure_callback)
			
			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())
			
			return (msg_list, failure_msg_list)

		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')
			
			handle = self._impl.lib.activ_session_query_snapshot(self._impl.session_context, data_source_id,
																query.encode(), int(parameters))

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def time_series_ticks(self, symbol, start, handler=None, symbology_id=None, user_data=None, data_source_id=None,
					   	  timeout=None, end=None, count=None, utc=False, filter='none', reverse=None):
		'''Request time series ticks.
		
		The method is synchronous by default and the results of the request are returned immediately.
		
		If a handler is provided then the request is asynchronous and results are received through the handler callbacks.

		Either end or count must be provided.
		The count and reverse parameters cannot be specified together.
		
		Parameters
		----------
		symbol : str
			Symbol to request time series data for.
		start : datetime.datetime
			The date time for the start of the data.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		symbology_id : int, optional
			Symbology of the symbol, uses the session default if not specified.
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
			Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		end : datetime.datetime, optional
			The date time to request data to.
		count : int, optional
			The number of results to return (negative to search backwards).
			Must be between -65535 and 65535.
		utc : bool, optional
			Indicates if the timezones of date times in the request are UTC, otherwise they will be in exchange local timezone.
		filter : { 'none', 'regular-trades', 'non-regular-trades', 'trades',
		           'trade-cancels-and-corrections', 'all-trades', 'luld-and-trading-status',
		           'bids', 'asks', 'quotes', 'quotes-and-trades' }, optional
			The filter to apply to records, defaults to 'none' for all records.
		reverse : bool, optional
			Whether the results should be returned in reverse chronological order (most recent first).

			This option can only be used when specifying an end datetime. When specifying a count the results are returned in the
			order that the data is searched.

		Returns
		-------
		list of TimeSeriesMessage
			By default, returns a list of TimeSeriesMessage objects retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the time series data.
		'''

		self._on_wakeup(True)
		
		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		symbology_id = symbology_id or self.default_symbology_id
		start_param = field_types._build_date_time(start)

		if end is None:
			end_param = _c_lib.C_FieldValueDateTime(_c_lib.C_FieldValueDate(0, 0, 0), _c_lib.C_FieldValueTime(0, 0, 0))

			if count is None:
				raise RuntimeError('either end or count must be specified')
		
			if reverse is not None:
				raise RuntimeError('reverse and count cannot be specified together')
		else:
			end_param = field_types._build_date_time(end)

			if count is not None:
				raise RuntimeError('end and count cannot be specified together')
		
		reverse = reverse or False
		count = count or 0

		params = _c_lib.C_TimeSeriesTickParameters(symbology_id, start_param, end_param, count, reverse, utc,
		                                           _time_series.Tick.string_to_filter(filter))

		if handler is None:
			msg_list = list()
			callback = _c_lib.C_SyncTimeSeriesMessageCallback(
				lambda msg_pointer : self._impl.time_series_sync_message_callback(msg_list, msg_pointer))
			
			status_code = self._impl.lib.activ_session_sync_time_series_ticks(
				self._impl.session_context, data_source_id, symbol.encode(), _session_impl.byref(params),
				timeout or 0xffffffff, callback)

			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())
		
			return msg_list
		
		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')
			
			handle = self._impl.lib.activ_session_time_series_ticks(self._impl.session_context, data_source_id,
																	symbol.encode(), _session_impl.byref(params))

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def time_series_intraday_bars(self, symbol, start, handler=None, symbology_id=None, user_data=None, data_source_id=None,
							   	  timeout=None, end=None, count=None, utc=False, interval='1m', filter='none', reverse=None):
		
		'''Request time series intraday bars.
		
		The method is synchronous by default and the results of the request are returned immediately.
		
		If a handler is provided then the request is asynchronous and results are received through the handler callbacks.

		Either end or count must be provided.
		The count and reverse parameters cannot be specified together.
		
		Parameters
		----------
		symbol : str
			Symbol to request time series data for.
		start : datetime.datetime
			The date time for the start of the data.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		symbology_id : int, optional
			Symbology of the symbol, uses the session default if not specified.
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
			Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		end : datetime.datetime, optional
			The date time to request data to.
		count : int, optional
			The number of results to return (negative to search backwards).
			Must be between -65535 and 65535.
		utc : bool, optional
			Indicates if the timezones of date times in the request are UTC, otherwise they will be in exchange local timezone.
		interval : { '1m', '2m', '5m', '10m', '15m', '30m', '60m' }, optional
			The interval for each bar, defaults to '1m' for 1 minute bars.
		filter : { 'none', 'regular-trades', ohlc-bars' }, optional
			The filter to apply to records, defaults to 'none'.
		reverse : bool, optional
			Whether the results should be returned in reverse chronological order (most recent first).

			This option can only be used when specifying an end datetime. When specifying a count the results are returned in the
			order that the data is searched.

		Returns
		-------
		list of TimeSeriesMessage
			By default, returns a list of TimeSeriesMessage objects retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the time series data.
		'''

		self._on_wakeup(True)
		
		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		symbology_id = symbology_id or self.default_symbology_id
		start_param = field_types._build_date_time(start)

		if end is None:
			end_param = _c_lib.C_FieldValueDateTime(_c_lib.C_FieldValueDate(0, 0, 0), _c_lib.C_FieldValueTime(0, 0, 0))

			if count is None:
				raise RuntimeError('either end or count must be specified')
		
			if reverse is not None:
				raise RuntimeError('reverse and count cannot be specified together')
		else:
			end_param = field_types._build_date_time(end)

			if count is not None:
				raise RuntimeError('end and count cannot be specified together')
		
		reverse = reverse or False
		count = count or 0

		params = _c_lib.C_TimeSeriesIntradayBarParameters(symbology_id, start_param, end_param, count, reverse, utc,
														  _time_series.IntradayBar.string_to_interval(interval),
														  _time_series.IntradayBar.string_to_filter(filter))

		if handler is None:
			msg_list = list()
			callback = _c_lib.C_SyncTimeSeriesMessageCallback(
				lambda msg_pointer : self._impl.time_series_sync_message_callback(msg_list, msg_pointer))
			
			status_code = self._impl.lib.activ_session_sync_time_series_intraday_bars(
				self._impl.session_context, data_source_id, symbol.encode(), _session_impl.byref(params),
				timeout or 0xffffffff, callback)

			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())
		
			return msg_list
		
		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')

			handle = self._impl.lib.activ_session_time_series_intraday_bars(self._impl.session_context, data_source_id,
																			symbol.encode(), _session_impl.byref(params))

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def time_series_history_bars(self, symbol, start, handler=None, symbology_id=None, user_data=None, data_source_id=None,
							  	 timeout=None, end=None, count=None, interval='daily', reverse=None):
		
		'''Request time series history bars.
		
		The method is synchronous by default and the results of the request are returned immediately.
		
		If a handler is provided then the request is asynchronous and results are received through the handler callbacks.

		Either end or count must be provided.
		The count and reverse parameters cannot be specified together.
		
		Parameters
		----------
		symbol : str
			Symbol to request time series data for.
		start : datetime.date
			The date for the start of the data.
		handler : object, optional
			Handler to receive messages on callbacks for asynchronous requests.
		symbology_id : int, optional
			Symbology of the symbol, uses the session default if not specified.
		user_data : any, optional
			User data to be associated with this request and provided during callbacks in Context.
			Only for asynchronous requests.
		data_source_id : int, optional
			Data source to use to fulfill the request, uses session default if not specified.
		timeout : int, optional
			Timeout in milliseconds to wait for the request.
			Only valid for synchronous requests.
		end : datetime.date, optional
			The date to request data to.
		count : int, optional
			The number of results to return (negative to search backwards).
			Must be between -65535 and 65535.
		interval : { 'daily', 'weekly', 'monthly' }, optional
			The interval for each bar, defaults to 'daily'.
		reverse : bool, optional
			Whether the results should be returned in reverse chronological order (most recent first).

			This option can only be used when specifying an end date. When specifying a count the results are returned in the
			order that the data is searched.

		Returns
		-------
		list of TimeSeriesMessage
			By default, returns a list of TimeSeriesMessage objects retrieved synchronously.
		
		Handle
			If a handler is specified, then the request is asynchronous and a Handle is returned for the request.
		
		Raises
		------
		RuntimeError
			Error requesting the time series data.
		'''
		
		self._on_wakeup(True)
		
		data_source_id = data_source_id if not (data_source_id is None) else self.default_data_source_id
		symbology_id = symbology_id or self.default_symbology_id
		start_param = field_types._build_date(start)

		if end is None:
			end_param = _c_lib.C_FieldValueDate(0, 0, 0)

			if count is None:
				raise RuntimeError('either end or count must be specified')
		
			if reverse is not None:
				raise RuntimeError('reverse and count cannot be specified together')
		else:
			end_param = field_types._build_date(end)

			if count is not None:
				raise RuntimeError('end and count cannot be specified together')
		
		reverse = reverse or False
		count = count or 0

		params = _c_lib.C_TimeSeriesHistoryBarParameters(symbology_id, start_param, end_param, count, reverse,
														 _time_series.HistoryBar.string_to_interval(interval))

		if handler is None:
			msg_list = list()
			callback = _c_lib.C_SyncTimeSeriesMessageCallback(
				lambda msg_pointer : self._impl.time_series_sync_message_callback(msg_list, msg_pointer))
			
			status_code = self._impl.lib.activ_session_sync_time_series_history_bars(
				self._impl.session_context, data_source_id, symbol.encode(), _session_impl.byref(params),
				timeout or 0xffffffff, callback)
			
			if status_code != constants.STATUS_CODE_SUCCESS:
				raise RuntimeError(self._get_error())
		
			return msg_list
		
		else:
			if not (timeout is None):
				raise RuntimeError('timeout cannot be specified for asynchronous requests')

			handle = self._impl.lib.activ_session_time_series_history_bars(self._impl.session_context, data_source_id,
																		symbol.encode(), _session_impl.byref(params))

			if constants.HANDLE_UNDEFINED == handle:
				raise RuntimeError(self._get_error())

			self._impl.handler_map[handle] = (handler, user_data)
			return types.Handle(self, handle)

	def to_pandas(self, result, field_names=True, to_native=True):
		'''Convert request results to a pandas DataFrame.
	
		Parameters
		----------
		result : object or list of object
			A message or a list of messages. Supported message types:
				QueryAddMessage
				SnapshotMessage
				SnapshotFailureMessage
				TimeSeriesMessage
			
			All messages must be of the same type.

		field_names : bool, optional
			Convert field ids to field names, default True.
		to_native : bool, optional
			Convert field values to native Python values, default True.
		
		Returns
		-------
		pandas.DataFrame
			DataFrame containing the results. Columns are padded with None if for messages that don't contain values for the field.

		Raises
		------
		RuntimeError
			Error converting messages to DataFrame.
		'''
		self._on_wakeup(False)
		return utils._to_pandas(self.metadata, result, field_names=field_names, to_native=to_native)

	def _check_publish_mode(self):
		if constants.FID_SESSION_PUBLISH_MODE in self.parameters:
			publish_data_source = self.parameters[constants.FID_SESSION_PUBLISH_DATA_SOURCE]

			try:
				self.metadata.get_data_source_dictionary(publish_data_source)
			except:
				raise RuntimeError(f'error fetching dictionary for publishing data source {publish_data_source}') from None

	def _get_snapshot_parameters(self, data_source_id, fields):
		# Need an immutable tuple to use as key in dict.
		fields_tuple = tuple(fields)
		handle = self._snapshot_parameters_map.get(fields_tuple)
		if handle is not None:
			return handle

		fid_list = []	
		for field in fields:
			if type(field) == int:
				fid_list.append(field)
			else:
				try:
					dictionary = self.metadata.get_data_source_dictionary(data_source_id)
				except:
					raise RuntimeError(f'dictionary not found for data source {data_source_id}') from None

				try:
					fid_list.append(dictionary.field_name_map[field].id)
				except:
					raise RuntimeError(f'field "{field}" not found') from None

		parameters = { constants.FID_FIELD_INCLUDE_FILTER: fid_list }
		handle = self.register_snapshot_parameters(parameters).value
		self._snapshot_parameters_map[fields_tuple] = handle
		return handle

	def _get_error(self):
		return self._impl.lib.activ_session_get_error_string(self._impl.session_context).decode()
