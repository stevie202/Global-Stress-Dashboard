from activfinancial.field_types import Rational
from activfinancial.market_data import separators

import datetime

#	To ensure consistent results the strike price numerator and denominator
#	should be compressed to the lowest value numerator. For example in the
#	encoding of the value 0.1 there are several options two of which are:
#		NUMERATOR = 1 , DECIMAL-PLACES=1 or
#		NUMERATOR = 10, DECIMAL-PLACES=2
#
#	These two examples will not result in consistent symbols. The correct
#	procedure is to use the first example where the numerator has the lowest
#	possible integer value. The Rational object provides a convenient
#	interface to ensure the strike price is suitably compressed. For further
#	details refer to the Rational.compress.
class UsEquityOptionHelper:

	# Blob format.
	# D = Day
	# M = Month
	# X = Numerator
	# Y = Year
	# Z = Denominator
	# BYTE-1:	Y6	Y5	Y4	Y3	Y2	Y1
	# BYTE-2:	Y0	M4	M3	M2	M1	M0
	# BYTE-3:	Z0	D4	D3	D2	D1	D0
	# BYTE-4:	X3	X2	X1	X0	Z2	Z1
	# BYTE-5:	X9	X8	X7	X6	X5	X4
	# BYTE-6;	X15	X14	X13	X12	X11	X10
	# BYTE-7;	X21	X20	X19	X18	X17	X16
	# BYTE-8;	X27	X26	X25	X24	X23	X22
	# BYTE-9;	-	-	X31	X30	X29	X28
	#
	# Blob will have a minimum length of 4 bytes and a maximum of 9 bytes.

	#! Option type enumeration.
	OPTION_TYPE_CALL = 0
	OPTION_TYPE_PUT  = 1

	#! Maximum length constants.
	MAX_ROOT_LENGTH = 6		# The maximum length of the root symbol
	MAX_EXCHANGE_LENGTH = 3	# The maximum length of the exchange code
	MIN_BLOB_LENGTH = 4		# The minimum length of the encoded blob
	MAX_BLOB_LENGTH = 9		# The maximum length of the encoded blob
	MAX_SYMBOL_LENGTH = MAX_ROOT_LENGTH + 1 + MAX_BLOB_LENGTH + 1 + MAX_EXCHANGE_LENGTH	# The maximum encoded symbol length including separators.

	OSI_ROOT_LENGTH = 6		# The osi root length.
	OSI_SYMBOL_LENGTH = 21	# The osi symbol length.

	#! Denominator enumeration.
	__DENOMINATOR_WHOLE = 0
	__DENOMINATOR_1DP = 1
	__DENOMINATOR_2DP = 2
	__DENOMINATOR_3DP = 3
	__DENOMINATOR_4DP = 4
	__DENOMINATOR_5DP = 5
	__DENOMINATOR_X5 = 6
	__DENOMINATOR_RESERVED = 7

	__CALL_MONTH_OFFSET = ord('A') - 1		# 'Call' month offset.
	__PUT_MONTH_OFFSET = ord('M') - 1		# 'Put' month offset.
	__ENCODED_MONTH_OFFSET = ord('A') - 4	# Offset applied to the encoded expiration month.

	#! Binary to base 64 encoding table.
	__BASE64_ENCODING_TABLE = (
		'A',	'B',	'C',	'D',	'E',	'F',	'G',	'H',
		'I',	'J',	'K',	'L',	'M',	'N',	'O',	'P',
		'Q',	'R',	'S',	'T',	'U',	'V',	'W',	'X',
		'Y',	'Z',	'a',	'b',	'c',	'd',	'e',	'f',
		'g',	'h',	'i',	'j',	'k',	'l',	'm',	'n',
		'o',	'p',	'q',	'r',	's',	't',	'u',	'v',
		'w',	'x',	'y',	'z',	'0',	'1',	'2',	'3',
		'4',	'5',	'6',	'7',	'8',	'9',	'^',	'~'
	)

	#! Undefined base 64 decoding table value.
	UD = 255

	#! Base 64 to binary decoding table.
	__BASE64_DECODING_TABLE = (
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		52,	53,	54,	55,	56,	57,	58,	59,	60,	61,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	0,	1,	2,	3,	4,	5,	6,	7,	8,	9,	10,	11,	12,	13,	14,
		15,	16,	17,	18,	19,	20,	21,	22,	23,	24,	25,	UD,	UD,	UD,	62,	UD,
		UD,	26,	27,	28,	29,	30,	31,	32,	33,	34,	35,	36,	37,	38,	39,	40,
		41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,	UD,	UD,	UD,	63,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,
		UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD,	UD
	)

	def __init__(self, symbol = ''):
		self.expiration_year = 0
		self.expiration_month = 0
		self.expiration_day = 0

		if symbol:
			self.deserialize(symbol)
		else:
			self.root = ''
			self.strike_price = Rational(Rational.DENOMINATOR_UNDEFINED, 0)
			self.exchange = ''

	def is_call(self):
		return self.expiration_month <= UsEquityOptionHelper.__PUT_MONTH_OFFSET

	def serialize(self):
		return UsEquityOptionHelper.serialize_symbol(self.root, self.expiration_year, self.expiration_month, self.expiration_day, self.strike_price, self.exchange)

	def deserialize(self, symbol):
		(self.root, self.expiration_year, self.expiration_month, self.expiration_day, self.strike_price, self.exchange) = UsEquityOptionHelper.deserialize_symbol(symbol)

	def set_expiration_date_and_option_type(self, expiration_date, option_type):
		self.expiration_year = expiration_date.year % 100
		self.expiration_month = expiration_date.month + (UsEquityOptionHelper.__CALL_MONTH_OFFSET if UsEquityOptionHelper.OPTION_TYPE_CALL == option_type else UsEquityOptionHelper.__PUT_MONTH_OFFSET)
		self.expiration_day = expiration_date.day

	def get_expiration_date_and_option_type(self):
		return UsEquityOptionHelper.get_date_and_option_type_from_expiration_date(self.expiration_year, self.expiration_month, self.expiration_day)

	@property
	def expiration_date(self):
		month = self.expiration_month - (UsEquityOptionHelper.__CALL_MONTH_OFFSET if self.is_call() else UsEquityOptionHelper.__PUT_MONTH_OFFSET)
		date = datetime.date(self.expiration_year + 2000, month, self.expiration_day)

		return date

	@property
	def option_type(self):
		return (UsEquityOptionHelper.OPTION_TYPE_CALL if self.is_call() else UsEquityOptionHelper.OPTION_TYPE_PUT)

	def build_alias_symbol(self):
		alias_symbol =  f"{self.root}"\
						f"{separators.EXPIRATION_DATE_SEPARATOR}{self.build_alias_expiration_date()}"\
						f"{separators.STRIKE_PRICE_SEPARATOR}{self.build_alias_strike_price()}"\
						f"{('C' if self.is_call() else 'P')}"\
						f"{separators.EXCHANGE_SEPARATOR}{self.exchange}"

		return alias_symbol

	def build_alias_strike_price(self):
		strike_price_numerator = Rational.scale_numerator(self.strike_price.numerator, self.strike_price.denominator, Rational.DENOMINATOR_3DP)
		return f"{str(strike_price_numerator) :0>8}"

	def build_alias_expiration_date(self):
		return self.expiration_date.strftime('%y%m%d')

	@classmethod
	def serialize_symbol(cls, root, expiration_year, expiration_month, expiration_day, strike_price, exchange):
		if (strike_price.numerator < 0) or (strike_price.numerator >= 2**32):
			raise ValueError('Numerator out of range - must be from 0 and 4,294,967,295')

		if len(root) > UsEquityOptionHelper.MAX_ROOT_LENGTH:
			raise ValueError('Length of root exceeds maximum size')

		if len(exchange) > UsEquityOptionHelper.MAX_EXCHANGE_LENGTH:
			raise ValueError('Length of exchange exceeds maximum size')

		(encoded_strike_price_numerator, encoded_strike_price_denominator) = UsEquityOptionHelper.__get_encoded_strike_price(strike_price.numerator, strike_price.denominator)

		symbol = f"{root}{separators.EXPIRATION_DATE_SEPARATOR}"\
				 f"{UsEquityOptionHelper.__BASE64_ENCODING_TABLE[(expiration_year >> 1) & 0x3f]}"\
				 f"{UsEquityOptionHelper.__BASE64_ENCODING_TABLE[((expiration_year << 5) | (expiration_month - UsEquityOptionHelper.__ENCODED_MONTH_OFFSET)) & 0x3f]}"\
				 f"{UsEquityOptionHelper.__BASE64_ENCODING_TABLE[((expiration_day) | (encoded_strike_price_denominator << 5)) & 0x3f]}"\
				 f"{UsEquityOptionHelper.__BASE64_ENCODING_TABLE[((encoded_strike_price_denominator >> 1) | (encoded_strike_price_numerator << 2)) & 0x3f]}"

		encoded_strike_price_numerator >>= 4
		while 0 != encoded_strike_price_numerator:
			symbol += f"{UsEquityOptionHelper.__BASE64_ENCODING_TABLE[encoded_strike_price_numerator & 0x3f]}"
			encoded_strike_price_numerator >>= 6

		symbol += f"{separators.EXCHANGE_SEPARATOR}{exchange}"

		return symbol

	@classmethod
	def serialize_symbol_with_date_and_option_type(cls, root, expiration_date, strike_price, exchange, option_type):
		(expiration_year, expiration_month, expiration_day) = UsEquityOptionHelper.get_expiration_date_from_date_and_option_type(expiration_date, option_type)
		return UsEquityOptionHelper.serialize_symbol(root, expiration_year, expiration_month, expiration_day, strike_price, exchange)

	@classmethod
	def deserialize_symbol(cls, symbol):
		if (len(symbol) > UsEquityOptionHelper.MAX_SYMBOL_LENGTH):
			raise ValueError('Symbol exceeds max symbol length')

		blob_start = symbol.find(separators.EXPIRATION_DATE_SEPARATOR)
		if blob_start == -1:
			raise ValueError('Expiration date separator not found')

		# Skip past the seperator.
		blob_start += 1

		blob_end = symbol.find(separators.EXCHANGE_SEPARATOR, blob_start)
		if blob_end == -1:
			raise ValueError('Exchange separator not found')

		blob = symbol[blob_start:blob_end]

		if len(blob) < UsEquityOptionHelper.MIN_BLOB_LENGTH:
			raise ValueError('Blob subceeds minimum blob length')

		root = symbol[0:blob_start - 1]
		exchange =  symbol[blob_end + 1:]

		if (len(symbol) - (len(root) + 1 + len(blob)) < 2):
			raise ValueError('Exchange not present in symbol')

		expiration_year = UsEquityOptionHelper.__BASE64_DECODING_TABLE[ord(blob[0])] << 1
		expiration_month = UsEquityOptionHelper.__BASE64_DECODING_TABLE[ord(blob[1])]
		expiration_day = UsEquityOptionHelper.__BASE64_DECODING_TABLE[ord(blob[2])]
		encoded_strike_price_numerator = UsEquityOptionHelper.__BASE64_DECODING_TABLE[ord(blob[3])]

		expiration_year |= (expiration_month >> 5)
		expiration_month = (expiration_month & 0x1f) + UsEquityOptionHelper.__ENCODED_MONTH_OFFSET

		encoded_strike_price_denominator = (expiration_day >> 5) | ((encoded_strike_price_numerator & 0x03) << 1)
		encoded_strike_price_numerator >>= 2

		expiration_day &= 0x1f

		numerator_offset = 4
		for blob_byte in blob[4:]:
			encoded_strike_price_numerator |= (UsEquityOptionHelper.__BASE64_DECODING_TABLE[ord(blob_byte)] << numerator_offset)
			numerator_offset += 6

		strike_price = UsEquityOptionHelper.__get_decoded_strike_price(encoded_strike_price_numerator, encoded_strike_price_denominator)

		return (root, expiration_year, expiration_month, expiration_day, strike_price, exchange)

	@classmethod
	def get_max_serialized_length(cls, root, exchange):
		BLOB_AND_SEPERATOR_LENGTH = UsEquityOptionHelper.MAX_BLOB_LENGTH + len(separators.EXPIRATION_DATE_SEPARATOR) + len(separators.EXCHANGE_SEPARATOR)

		return len(root) + len(exchange) + BLOB_AND_SEPERATOR_LENGTH

	@classmethod
	def get_date_and_option_type_from_expiration_date(cls, expiration_year, expiration_month, expiration_day):
		if expiration_month <= UsEquityOptionHelper.__PUT_MONTH_OFFSET:
			expiration_date = datetime.date(expiration_year + 2000, expiration_month - UsEquityOptionHelper.__CALL_MONTH_OFFSET, expiration_day)
			return (expiration_date, UsEquityOptionHelper.OPTION_TYPE_CALL)
		else:
			expiration_date = datetime.date(expiration_year + 2000, expiration_month - UsEquityOptionHelper.__PUT_MONTH_OFFSET, expiration_day)
			return (expiration_date, UsEquityOptionHelper.OPTION_TYPE_PUT)

	@classmethod
	def get_expiration_date_from_date_and_option_type(cls, expiration_date, option_type):
		expiration_year = expiration_date.year % 100
		expiration_month =  expiration_date.month + (UsEquityOptionHelper.__CALL_MONTH_OFFSET if UsEquityOptionHelper.OPTION_TYPE_CALL == option_type else UsEquityOptionHelper.__PUT_MONTH_OFFSET)
		expiration_day = expiration_date.day

		return (expiration_year, expiration_month, expiration_day)

	@classmethod
	def get_symbol_from_osi_symbol(cls, osi_symbol, exchange):
		if UsEquityOptionHelper.OSI_SYMBOL_LENGTH != len(osi_symbol):
			raise ValueError('Incorrect OSI symbol length')

		helper = UsEquityOptionHelper()

		root_length = min(osi_symbol.find(" "), UsEquityOptionHelper.OSI_ROOT_LENGTH)
		if root_length == -1:
			root_length = min(len(osi_symbol), UsEquityOptionHelper.OSI_ROOT_LENGTH)

		helper.root = osi_symbol[:root_length]
		helper.expiration_year = int(osi_symbol[6:8])
		helper.expiration_day  = int(osi_symbol[10:12])
		call_put = osi_symbol[12:13]
		helper.expiration_month = int(osi_symbol[8:10]) + (UsEquityOptionHelper.__CALL_MONTH_OFFSET if call_put == 'C' else UsEquityOptionHelper.__PUT_MONTH_OFFSET)

		strike_price_numerator = int(osi_symbol[13:])

		helper.strike_price = Rational(Rational.DENOMINATOR_3DP, strike_price_numerator, True)
		helper.exchange = exchange

		return helper.serialize()

	@classmethod
	def get_osi_symbol_from_symbol(cls, symbol):
		helper = UsEquityOptionHelper(symbol)

		osi_symbol = f"{helper.root : <6}{helper.build_alias_expiration_date()}"\
					 f"{('C' if helper.expiration_month <= UsEquityOptionHelper.__PUT_MONTH_OFFSET else 'P')}"\
					 f"{helper.build_alias_strike_price()}"

		return osi_symbol

	@classmethod
	def __get_encoded_strike_price(cls, strike_price_numerator, strike_price_denominator):
		encoded_strike_price_numerator = strike_price_numerator

		if (strike_price_denominator == Rational.DENOMINATOR_WHOLE) and (0 == (encoded_strike_price_numerator % 5)):
			encoded_strike_price_numerator //= 5
			encoded_strike_price_denominator = UsEquityOptionHelper.__DENOMINATOR_X5
		else:
			encoded_strike_price_denominator = strike_price_denominator

		return (encoded_strike_price_numerator, encoded_strike_price_denominator)

	@classmethod
	def __get_decoded_strike_price(cls, encoded_strike_price_numerator, encoded_strike_price_denominator):
		strike_price_numerator = encoded_strike_price_numerator

		if UsEquityOptionHelper.__DENOMINATOR_X5 == encoded_strike_price_denominator:
			strike_price_numerator *= 5
			strike_price_denominator = Rational.DENOMINATOR_WHOLE
		else:
			strike_price_denominator = encoded_strike_price_denominator

		return Rational(strike_price_denominator, strike_price_numerator)
