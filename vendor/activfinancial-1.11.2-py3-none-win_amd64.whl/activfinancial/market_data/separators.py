INDEX_IDENTIFIER_SEPARATOR = '='
CORPORATE_ACTION_SEPARATOR = '%'
DEAD_INSTRUMENT_SEPARATOR = '#'
EXCHANGE_SEPARATOR = '.'
EXPIRATION_DATE_SEPARATOR = '/'
FORWARD_CODE_SEPARATOR = '/'
LEVEL2_SEPARATOR = '-'
MARKET_SEPARATOR = '/'
NEWS_SOURCE_SEPARATOR = '%'
ORDER_SEPARATOR = ';'
QUOTE_SEPARATOR = ':'
RANKINGS_SEPARATOR = '+'
SPREAD_FUTURES_SEPARATOR = '-'
STATISTICS_SEPARATOR = '+'
STRIKE_PRICE_SEPARATOR = '/'
SYMBOL_SEPARATOR = ' '
NON_COMMON_ISSUE_SEPARATOR = ','

composite_symbol_separator_list = [
	EXCHANGE_SEPARATOR,
	QUOTE_SEPARATOR,
	ORDER_SEPARATOR,
	CORPORATE_ACTION_SEPARATOR,
	DEAD_INSTRUMENT_SEPARATOR ]

exchange_separator_list = [
	EXCHANGE_SEPARATOR,
	CORPORATE_ACTION_SEPARATOR,
	DEAD_INSTRUMENT_SEPARATOR ]

level2_separator_list = [
	QUOTE_SEPARATOR,
	ORDER_SEPARATOR,
	LEVEL2_SEPARATOR ]

def _find_last_of(string, separators):
	for i in range(len(string) - 1, 0, -1):
		if string[i] in separators:
			return i

	return -1

def _find_first_of(string, separators, offset):
	for i in range(offset, len(string) - 1):
		if string[i] in separators:
			return i

	return -1

def get_exchange(symbol):
	exchange_index = _find_last_of(symbol, exchange_separator_list)

	if -1 == exchange_index:
		return ''

	level2_index = _find_first_of(symbol, level2_separator_list, exchange_index + 1)

	if -1 == level2_index:
		return symbol[exchange_index + 1:]
	else:
		return symbol[exchange_index + 1:level2_index]

def get_default_composite_symbol(symbol):
	index = _find_last_of(symbol, composite_symbol_separator_list);

	if -1 == index:
		return symbol
	else:
		return symbol[:index + 1]
