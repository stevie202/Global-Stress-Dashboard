from activfinancial import utils

from activfinancial.market_data import field_ids
from activfinancial.market_data import separators
from activfinancial.market_data import table_numbers

from activfinancial import _c_lib
from activfinancial import constants
from activfinancial import field_types

import datetime
import platform

#! Exchange info.
class ExchangeInfo:
	def __init__(self, session):
		self.session = session
		self._c_api_instance = None

		self.symbol = ''
		self.name = ''
		self.olson_timezone = ''
		self.microsoft_timezone = ''
		self.timezone = ''
		self.holiday_date_list = None

	def convert_date_time_to_utc(self, date, time):
		if not self._c_api_instance:
			raise RuntimeError("C API ExchangeInfo instance unavailable.")

		dateField = field_types._build_date(date)
		timeField = field_types._build_time(time)
		dateTime = _c_lib.C_FieldValueDateTime(dateField, timeField)

		result = self.session._impl.lib.activ_exchange_info_convert_date_time_to_utc(self._c_api_instance, dateField, timeField, dateTime)

		if (result != constants.STATUS_CODE_SUCCESS):
			raise RuntimeError(f"Conversion failure - {utils.status_code_to_string(result)}")

		return dateTime.convert()

#! Exchange info helper.
class ExchangeInfoHelper:

	#! States.
	STATE_INIT = 0
	STATE_SYNCHRONIZING = 1
	STATE_OK = 2
	STATE_ERROR = 3

	__US_COMPOSITE_EXCHANGE = "US"

	def __init__(self, session):
		self.state = ExchangeInfoHelper.STATE_INIT
		self.session = session
		self.snapshots_received = 0
		self.exchange_info_map = {}
		self.snapshot_handle_set = set()
		self.query_handle = session.query(f"table={table_numbers.TABLE_NO_EXCHANGE}", handler=self,
										  data_source_id=constants.DATA_SOURCE_ACTIV)

	def __del__(self):
		self.__close()

	def __enter__(self):
		return self

	def __exit__(self, exc_type, exc_val, exc_tb):
		self.__close()

	def get_exchange_info(self, symbol):
		if not symbol:
			exchange = ExchangeInfoHelper.__US_COMPOSITE_EXCHANGE
		else:
			result = -1
			for exchange_separator in separators.exchange_separator_list:
				result = symbol.rfind(exchange_separator)
				if result != -1:
					break
			if result == -1:
				exchange = symbol
			else:
				exchange = separators.get_exchange(symbol)
				if not exchange:
					exchange = ExchangeInfoHelper.__US_COMPOSITE_EXCHANGE

		return self.exchange_info_map[exchange]

	def state_to_string(self):
		if ExchangeInfoHelper.STATE_INIT == self.state:
			return 'init'
		elif ExchangeInfoHelper.STATE_SYNCHRONIZING == self.state:
			return 'synchronizing'
		elif ExchangeInfoHelper.STATE_OK == self.state:
			return 'ok'
		elif ExchangeInfoHelper.STATE_ERROR == self.state:
			return 'error'
		else:
			return 'unknown'

	#! Query Handler interface.
	def on_query_add(self, msg, context):
		handle = context.session.snapshot(msg.symbol, handler=self, data_source_id=constants.DATA_SOURCE_ACTIV)
		self.snapshot_handle_set.add(handle.value)
		self.exchange_info_map[msg.symbol] = ExchangeInfo(context.session)

	def on_query_status(self, msg, context):
		if msg.is_pending():
			self.state = ExchangeInfoHelper.STATE_SYNCHRONIZING
		elif msg.is_complete():
			if not self.exchange_info_map:
				self.state = ExchangeInfoHelper.STATE_ERROR

			self.query_handle.close()
			self.check_and_update_state()
		elif msg.is_error() or msg.is_failure():
			self.state = ExchangeInfoHelper.STATE_ERROR
			self.query_handle.close()

	#! Snapshot Handler interface.
	def on_snapshot(self, msg, context):
		self.snapshots_received += 1
		self.check_and_update_state()

		exchange_info = self.exchange_info_map[msg.symbol]

		exchange_info.symbol = msg.symbol
		exchange_info.name = msg.fields[field_ids.FID_NAME].value
		exchange_info.olson_timezone = msg.fields[field_ids.FID_OLSON_TIME_ZONE].value
		exchange_info.microsoft_timezone = msg.fields[field_ids.FID_MICROSOFT_TIME_ZONE].value

		if ('Windows' == platform.system()):
			exchange_info.timezone = exchange_info.microsoft_timezone
		else:
			exchange_info.timezone = exchange_info.olson_timezone

		date_list_field = msg.fields[field_ids.FID_EXCHANGE_HOLIDAY_LIST]
		if (date_list_field.is_defined()):
			exchange_info.holiday_date_list = ExchangeInfoHelper.get_date_list_from_string(str(date_list_field))
		else:
			exchange_info.holiday_date_list = []

		self._make_c_api_exchange_info(msg, exchange_info)

		self.snapshot_handle_set.remove(context.handle.value)
		context.session.close_handle(context.handle)

	def on_snapshot_failure(self, msg, context):
		self.exchange_info_map.remove(msg.symbol)
		self.state = ExchangeInfoHelper.STATE_ERROR
		context.session.close_handle(context.handle)

		self.query_handle.close()

	def check_and_update_state(self):
		if ExchangeInfoHelper.STATE_SYNCHRONIZING == self.state \
		and len(self.exchange_info_map) == self.snapshots_received \
		and not self.query_handle:
			self.state = ExchangeInfoHelper.STATE_OK

	@classmethod
	def get_date_list_from_string(cls, stringified_date_list):
		date_set = set()
		date_string_list = stringified_date_list.split()
		for date_string in date_string_list:
			date = datetime.datetime.strptime(date_string, '%Y-%m-%d').date()
			date_set.add(date)

		return sorted(date_set)

	def __close(self):
		if self.query_handle:
			self.query_handle.close()

		for snapshot_handle in self.snapshot_handle_set:
			self.session.close_handle(snapshot_handle)

		self.snapshot_handle_set.clear()

	def _make_c_api_exchange_info(self, msg, exchange_info):
		utc_offset = msg.fields[field_ids.FID_UTC_OFFSET]
		if not utc_offset.is_defined():
			return

		dst_offset = msg.fields[field_ids.FID_DST_OFFSET]
		if not dst_offset.is_defined():
			return

		dst_start_date_time = msg.fields[field_ids.FID_DST_START_DATE_TIME]
		if not dst_start_date_time.is_defined():
			return

		dst_end_date_time = msg.fields[field_ids.FID_DST_END_DATE_TIME]
		if not dst_end_date_time.is_defined():
			return

		dst_start_date_field = field_types._build_date_time(dst_start_date_time.value)
		dst_end_date_field = field_types._build_date_time(dst_end_date_time.value)

		exchange_info._c_api_instance = self.session._impl.lib.activ_exchange_info_init(
			self.session._impl.session_context,
			exchange_info.timezone.encode(),
			utc_offset.value,
			dst_offset.value,
			dst_start_date_field,
			dst_end_date_field)
