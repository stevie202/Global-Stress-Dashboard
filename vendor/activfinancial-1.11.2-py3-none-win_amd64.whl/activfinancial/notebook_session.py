from . import constants
from . import session

import datetime
import threading
import time
import weakref

# =============================================================================

# Debugging

class _DebugLogger:
    def __init__(self, widget):
        self.lines = []
        self.widget = widget
        self.lock = threading.Lock()

    def __call__(self, msg):
        with self.lock:
            # https://github.com/jupyter-widgets/ipywidgets/issues/3260
            self.widget.outputs = ()

            self.lines.append(f'{datetime.datetime.now()}: {msg}\n')
            if len(self.lines) > 10:
                self.lines.pop(0)

            for line in self.lines:
                self.widget.append_stdout(line)

_debug = lambda msg : None

def enable_debug(widget):
    global _debug
    _debug = _DebugLogger(widget)

# =============================================================================

class _Manager:
    def __init__(self):
        self.lock = threading.Lock()
        self.background_thread = None

        # Sets of idle/active sessions, stored as weak references.
        self.idle_sessions = set()
        self.active_sessions = set()
        self.initialized = False
        
    def is_background_thread(self):
        return threading.get_ident() == self.background_thread.ident
    
    def background_thread_run(self):
        try:
            while True:
                with self.lock:
                    # Shutdown background thread if there no sessions.
                    if len(self.idle_sessions) == 0 and len(self.active_sessions) == 0:
                        self.background_thread = None
                        _debug('Background thread stopped')
                        return
                    
                    # Build new set of sessions that are still valid.
                    old_set = self.idle_sessions
                    self.idle_sessions = set()

                    now = time.time()
                    for session_ref in old_set:
                        session = session_ref()

                        if session is None:
                            _debug(f'session removed {session_ref}')
                            continue # session deleted
                        
                        self.idle_sessions.add(session_ref)
                        idle_time = now - session.last_activity_time
                        if idle_time > session.activity_timeout:
                            if constants.SESSION_STATE_CONNECTED == session.get_state():
                                # Disconnect after a period of inactivity.
                                session.disconnect()
                                _debug(f'disconnected after {idle_time}s idle (session {session})')

                        session.process()

                # Sleep ~10ms each loop.
                time.sleep(0.01)

        except Exception as e:
            with self.lock:
                self.background_thread = None
                _debug(f'Exception on background thread - {str(e)}')

    def on_post_run_cell(self, result):
        # Cell finished running.
        with self.lock:
            # Update activated sessions' last activity time and mark inactive.
            for session_ref in self.active_sessions:
                session = session_ref()
                if session is not None:
                    session.last_activity_time = time.time()
                    session.is_active = False
            
            # Move activated sessions to idle.
            self.idle_sessions = self.idle_sessions.union(self.active_sessions)
            self.active_sessions = set()

    def add_session(self, session):
        with self.lock:
            self.active_sessions.add(weakref.ref(session))

            if not self.initialized:
                from IPython import get_ipython
                get_ipython().events.register('post_run_cell', self.on_post_run_cell)

                # Start a background thread as a daemon thread.
                self.background_thread = threading.Thread(target=self.background_thread_run, daemon=True)
                self.background_thread.start()

                _debug('background thread started')
                self.initialized = True
            
            _debug(f'added session {session}')

    def activate_session(self, session):
        with self.lock:
            self.idle_sessions.remove(weakref.ref(session))
            self.active_sessions.add(weakref.ref(session))

_manager = _Manager()

# =============================================================================

# NotebookSession.
class NotebookSession(session.Session):
    '''The NotebookSession class extends the Session class to ease use inside a Jupyter notebook.

        * The session runs in a background thread whilst cells are not executing.
        * The session disconnects when not in use and reconnects when used.
        * After cell completion, async requests continue in the background thread.
    
    Parameters
    ----------

    parameters : dict, optional
        Dictionary of session parameters, default empty.
    handler : object, optional
        Handler to receive session notification callbacks.
    dll_path : str, optional
        Explicit path to the C++ libraries. The path is discovered automatically if not specified.
    activity_timeout : int, optional
        Inactivity period in seconds before the session is automatically disconnected.
    
    Raises
    ------

    RuntimeError
        Failure to load libraries or invalid parameter specified.
    
    Warnings
    --------

    NotebookSession should not be used in user threads outside of cells. Use the Session class instead.
    '''
        
    # Constructor.
    def __init__(self, parameters={}, handler=None, dll_path=None, activity_timeout=600):

        global _manager

        # Always enable metadata for NotebookSession
        parameters[constants.FID_ENABLE_DICTIONARY_DOWNLOAD] = True

        super().__init__(parameters=parameters, handler=handler, dll_path=dll_path)

        self.activity_timeout = activity_timeout
        self.last_activity_time = time.time()

        # Connect notebook session on construction.
        super().connect(parameters, timeout=10000)

        _manager.add_session(self)
        self.is_active = True
        self._on_wakeup = self._wakeup

    def _wakeup(self, should_connect):
        global _manager

        if self.is_active:
            return

        # Don't try wakup for background thread!
        if _manager.is_background_thread():
            return
    
        _manager.activate_session(self)
        self.is_active = True

        # Reconnect if disconnected.
        if should_connect and self.get_state() != constants.SESSION_STATE_CONNECTED:
            _debug(f'reconnecting (session {self})')
            super().connect(self.parameters, timeout=10000)
            _debug(f'connected (session {self})')
