from . import constants
from . import session

# Class to provide a legacy R10 interface to the simplified >=R11 API.
class LegacySession(session.Session):
	def __init__(self, parameters={}, handler=None, dll_path=None):
		super().__init__(parameters, handler, dll_path=dll_path)

	# Unmodified methods.
	#def get_state(self)
	#def connect(self, parameters = {}, timeout = 5000):
	#def async_connect(self, parameters = {}):
	#def disconnect(self)
	#def get_parameters(self)
	#def process(self)
	#def run(self)
	#def post_user_message(cls, session, message)
	#def post_task(cls, session, task)
	#def shutdown(cls, session)
	#def close_handle(self, handle)
	#def register_snapshot_parameters
	#def register_subscription_parameters
	#def publish

	def snapshot(self, data_source_id, symbol, handler, symbology_id=constants.SYMBOLOGY_NATIVE, parameters=constants.HANDLE_UNDEFINED, user_data=None):
		return super().snapshot(symbol, handler=handler, data_source_id=data_source_id, symbology_id=symbology_id, parameters=parameters, user_data=user_data)

	def subscribe(self, data_source_id, symbol, handler, symbology_id=constants.SYMBOLOGY_NATIVE, parameters=constants.HANDLE_UNDEFINED, user_data=None):
		return super().subscribe(symbol, handler=handler, data_source_id=data_source_id, symbology_id=symbology_id, parameters=parameters, user_data=user_data)

	def query(self, data_source_id, query, handler, user_data=None):
		return super().query(query, handler=handler, data_source_id=data_source_id, user_data=user_data)

	def sync_query(self, data_source_id, query, timeout=0xffffffff):
		return super().query(query, timeout=timeout, data_source_id=data_source_id)

	def query_subscribe(self, data_source_id, query, handler, parameters=constants.HANDLE_UNDEFINED, user_data=None):
		return super().query_subscribe(query, handler=handler, data_source_id=data_source_id, parameters=parameters, user_data=user_data)

	def query_snapshot(self, data_source_id, query, handler, parameters=constants.HANDLE_UNDEFINED, user_data=None):
		return super().query_snapshot(query, handler=handler, data_source_id=data_source_id, parameters=parameters, user_data=user_data)
