import functools

from . import constants

def DictValueToFieldMapString(value, nesting):
	if isinstance(value, bool):
		return f"13:{str('true' if value else 'false')}"
	elif isinstance(value, int):
		return f"4:{str(value)}"
	elif isinstance(value, str):
		return f"7:{str(value)}"
	elif isinstance(value, list):
		return '15:' + functools.reduce(lambda x, y: x + ('\\' * nesting) + ',' + y, map(lambda x: DictValueToFieldMapString(x, nesting + 1), value))

def DictToFieldMapString(d):
	strings = []
	for (fid, value) in d.items():
		strings.append(str(fid) + '=' + DictValueToFieldMapString(value, 1))

	if len(strings) > 0:
		return functools.reduce(lambda x, y: x + ',' + y, strings)

	return ''

class DeprecatedQueryHandler:
	def __init__(self, handler):
		self.handler = handler

	def on_query_add(self, msg, context):
		self.handler.on_query_add(msg, context)

	def on_query_remove(self, msg, context):
		self.handler.on_query_remove(msg, context)
	
	def on_query_status(self, msg, context):
		if constants.QUERY_STATE_PENDING == msg.state:
			self.handler.on_query_start(context)
		elif constants.QUERY_STATE_COMPLETE == msg.state:
			self.handler.on_query_complete(context)
		elif constants.QUERY_STATE_ERROR == msg.state:
			self.handler.on_query_error(msg.status_code, context)
		else:
			self.handler.on_query_failure(msg.status_code, context)

class DeprecatedSubscriptionHandler:
	def __init__(self, handler):
		self.handler = handler

	def on_subscription_refresh(self, msg, context):
		self.handler.on_subscription_refresh(msg, context)

	def on_subscription_update(self, msg, context):
		self.handler.on_subscription_update(msg, context)

	def on_subscription_topic_status(self, msg, context):
		self.handler.on_subscription_topic_status(msg, context)

	def on_subscription_status(self, msg, context):
		if constants.SUBSCRIPTION_STATE_ERROR == msg.state:
			self.handler.on_subscription_error(msg.status_code, context)
		elif constants.SUBSCRIPTION_STATE_FAILURE == msg.state:
			self.handler.on_subscription_failure(msg.status_code, context)

		# pending and complete states do not have a callback with the old interface
