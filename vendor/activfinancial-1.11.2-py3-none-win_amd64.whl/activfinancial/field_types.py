from . import _c_lib
from . import constants

import datetime
import math

class Time:
	RESOLUTION_UNKNOWN = 0
	RESOLUTION_SECOND = 3
	RESOLUTION_MILLISECOND = 4
	RESOLUTION_MICROSECOND = 5
	RESOLUTION_NANOSECOND = 7

	def __init__(self, resolution = RESOLUTION_UNKNOWN, seconds_in_day = 0, sub_second = 0):
		self.resolution = resolution
		self.seconds_in_day = seconds_in_day
		self.sub_second = sub_second

	def hour(self):
		'''Get the hour'''
		return int(self.seconds_in_day / 3600)

	def minute(self):
		'''Get the minute in the hour'''
		return int((self.seconds_in_day % 3600) / 60)

	def second(self):
		'''Get the seconds in the minute'''
		return self.seconds_in_day % 60

	def millisecond(self):
		'''Get the sub second component as milliseconds'''
		if Time.RESOLUTION_SECOND == self.resolution:
			return 0
		elif Time.RESOLUTION_MILLISECOND == self.resolution:
			return self.sub_second
		elif Time.RESOLUTION_MICROSECOND == self.resolution:
			return int(self.sub_second / 1000)
		elif Time.RESOLUTION_NANOSECOND == self.resolution:
			return int(self.sub_second / 1000000)

	def microsecond(self):
		'''Get the sub second component as microseconds'''
		if Time.RESOLUTION_SECOND == self.resolution:
			return 0
		elif Time.RESOLUTION_MILLISECOND == self.resolution:
			return self.sub_second * 1000
		elif Time.RESOLUTION_MICROSECOND == self.resolution:
			return self.sub_second
		elif Time.RESOLUTION_NANOSECOND == self.resolution:
			return int(self.sub_second / 1000)

	def nanosecond(self):
		'''Get the sub second component as nanoseconds'''
		if Time.RESOLUTION_SECOND == self.resolution:
			return 0
		elif Time.RESOLUTION_MILLISECOND == self.resolution:
			return self.sub_second * 1000000
		elif Time.RESOLUTION_MICROSECOND == self.resolution:
			return self.sub_second * 1000
		elif Time.RESOLUTION_NANOSECOND == self.resolution:
			return self.sub_second

	def to_native(self):
		'''Convert to a datetime.time, note this does not support nanosecond resolution'''
		return datetime.time(self.hour(), self.minute(), self.second(), self.microsecond())

	def __str__(self):
		if Time.RESOLUTION_SECOND == self.resolution:
			sub_second_str = ''
		elif Time.RESOLUTION_MILLISECOND == self.resolution:
			sub_second_str = f".{self.millisecond():03}"
		elif Time.RESOLUTION_MICROSECOND == self.resolution:
			sub_second_str = f".{self.microsecond():06}"
		elif Time.RESOLUTION_NANOSECOND == self.resolution:
			sub_second_str = f".{self.nanosecond():09}"

		return f"{self.hour():02}:{self.minute():02}:{self.second():02}{sub_second_str}"

	def __hash__(self):
		time_string = str(self).rstrip('0.')
		return hash(time_string)

	def __eq__(self, rhs):
		return self.compare(rhs) == 0

	def compare(self, rhs):
		NANOSECONDS_PER_SECOND = 1e+9

		lhs_nanoseconds = int(self.seconds_in_day * NANOSECONDS_PER_SECOND) + self.nanosecond()
		rhs_nanoseconds = int(rhs.seconds_in_day * NANOSECONDS_PER_SECOND) + rhs.nanosecond()

		return (0 if lhs_nanoseconds == rhs_nanoseconds else (1 if lhs_nanoseconds > rhs_nanoseconds else -1))

class DateTime:
	def __init__(self, date = datetime.date.min , time = Time()):
		self.date = date
		self.time = time

	@property
	def year(self):
		return self.date.year

	@property
	def month(self):
		return self.date.month

	@property
	def day(self):
		return self.date.day

	def to_native(self):
		return datetime.datetime.combine(self.date, self.time.to_native())

	def __str__(self):
		return str(self.date) + ' ' + str(self.time)

	def __hash__(self):
		return hash(self.to_native())

	def __eq__(self, rhs):
		return self.to_native() == rhs.to_native()

class Rational:
	DENOMINATOR_WHOLE = 0
	DENOMINATOR_1DP = 1
	DENOMINATOR_2DP = 2
	DENOMINATOR_3DP = 3
	DENOMINATOR_4DP = 4
	DENOMINATOR_5DP = 5
	DENOMINATOR_6DP = 6
	DENOMINATOR_7DP = 7
	DENOMINATOR_8DP = 8
	DENOMINATOR_9DP = 9
	DENOMINATOR_X1E1 = 10
	DENOMINATOR_X1E2 = 11
	DENOMINATOR_X1E3 = 12
	DENOMINATOR_X1E4 = 13
	DENOMINATOR_X1E5 = 14
	DENOMINATOR_X1E6 = 15
	DENOMINATOR_X1E7 = 16
	DENOMINATOR_X1E8 = 17
	DENOMINATOR_X1E9 = 18
	DENOMINATOR_HALF = 19
	DENOMINATOR_QUARTER = 20
	DENOMINATOR_8TH = 21
	DENOMINATOR_16TH = 22
	DENOMINATOR_32ND = 23
	DENOMINATOR_64TH = 24
	DENOMINATOR_128TH = 25
	DENOMINATOR_256TH = 26
	DENOMINATOR_512TH = 27
	DENOMINATOR_CABINET = 28
	DENOMINATOR_UNDEFINED = 29
	DENOMINATOR_10DP = 30
	DENOMINATOR_11DP = 31
	DENOMINATOR_12DP = 32
	DENOMINATOR_13DP = 33
	DENOMINATOR_14DP = 34

	_DIVISOR = [
		# WHOLE -> 1DP
		1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000,
		# X1E1 -> X1E9 (negative means multiply)
		-10, -100, -1000, -10000, -100000, -1000000, -10000000, -100000000, -1000000000,
		# HALF -> 512TH
		2, 4, 8, 16, 32, 64, 128, 256, 512,
		# CABINET, UNDEFINED
		0, 0,
		# 10DP -> 14DP
		10000000000, 100000000000, 1000000000000, 10000000000000, 100000000000000 ]

	_DIVISOR_WIDTH = list(map(lambda x: len(str(x) if x >= 0 else str(-x)), _DIVISOR))

	def __init__(self, denominator, numerator, should_compress = False):
		self.denominator = denominator
		self.numerator = numerator

		if should_compress:
			self.compress()

	def to_native(self):
		'''Convert to a float, or return None for special denominator values'''
		if self.denominator >= len(Rational._DIVISOR):
			raise ValueError(f"invalid denominator {self.denominator}")

		divisor = Rational._DIVISOR[self.denominator]

		if divisor > 0:
			return float(self.numerator) / divisor
		elif divisor < 0:
			return float(self.numerator) * -divisor
		else:
			return None

	def __str__(self):
		if self.denominator >= len(Rational._DIVISOR):
			raise ValueError(f"invalid denominator {self.denominator}")

		if Rational.DENOMINATOR_UNDEFINED == self.denominator:
			return '[UndefinedValue]'

		if Rational.DENOMINATOR_CABINET == self.denominator:
			return '[CabinetValue]'

		if Rational.DENOMINATOR_WHOLE == self.denominator:
			return str(self.numerator)

		divisor = Rational._DIVISOR[self.denominator]
		divisor_width = Rational._DIVISOR_WIDTH[self.denominator]

		if divisor < 0:
			# Multiplier
			return f"{self.numerator}*10^{divisor_width - 1}"

		sign = '' if self.numerator >= 0 else '-'
		unsigned_numerator = abs(self.numerator)

		if (divisor % 10) == 0:
			# Decimal divisor
			return f"{sign}{int(unsigned_numerator / divisor)}.{int(unsigned_numerator % divisor):0{divisor_width - 1}}"

		elif divisor > 0:
			# Binary divisor
			whole_part = ''
			if int(unsigned_numerator / divisor) > 0:
				whole_part = f"{sign}{int(unsigned_numerator / divisor)} "

			return f"{whole_part}{unsigned_numerator % divisor}/{divisor}"
		else:
			raise ZeroDivisionError()

	def compress(self):
		divisor = abs(Rational._DIVISOR[self.denominator])
		factor  = 10 if Rational.__is_divisor_decimal(divisor) else 2

		iterations = 0
		while (divisor > 1) and ((self.numerator % factor) == 0):
			self.numerator //= factor
			divisor //= factor
			iterations += 1

		if divisor <= 1:
			self.denominator = Rational.DENOMINATOR_WHOLE
		elif Rational._DIVISOR[self.denominator] == divisor:
			# noop. Keep the denominator the same - it can't be normalized.
			pass
		elif (self.denominator < Rational.DENOMINATOR_UNDEFINED) or ((self.denominator - iterations) >= Rational.DENOMINATOR_10DP):
			self.denominator = self.denominator - iterations
		else:
			denominator_difference = Rational.DENOMINATOR_10DP - Rational.DENOMINATOR_9DP
			self.denominator = self.denominator - iterations - denominator_difference

	@classmethod
	def scale_numerator(cls, numerator, source_denominator, target_denominator):
		if source_denominator >= len(Rational._DIVISOR)\
		or target_denominator >= len(Rational._DIVISOR):
			raise RuntimeError('invalid denominator')

		if source_denominator == target_denominator:
			return numerator

		if Rational.DENOMINATOR_UNDEFINED == source_denominator:
			raise RuntimeError('Source denominator undefined.')

		if Rational.DENOMINATOR_UNDEFINED == target_denominator:
			raise RuntimeError('Target denominator undefined')

		if Rational.DENOMINATOR_CABINET == target_denominator:
			raise RuntimeError('Target denominator is "Cabinet"')

		source_divisor = Rational._DIVISOR[source_denominator]
		target_divisor = Rational._DIVISOR[target_denominator]

		source_multiplier = abs(source_divisor)
		target_multiplier = abs(target_divisor)

		if source_divisor < 0: # is_multiplier
			if target_divisor < 0: # is multiplier
				if source_multiplier <= target_multiplier:
					return Rational.__divide_numerator(numerator, (target_multiplier / source_multiplier))
				return Rational.__multiply_numerator(numerator, (source_multiplier / target_multiplier))
			return Rational.__multiply_numerator(numerator, (source_multiplier * target_divisor))
		if target_denominator < 0: # is multiplier
			return Rational.__divide_numerator(numerator, (target_multiplier * source_divisor))

		# Is divisor decimal or is divisor binary?
		if Rational.__is_divisor_decimal(source_divisor) and Rational.__is_divisor_decimal(target_divisor) \
		or Rational.__is_divisor_binary(source_divisor) and Rational.__is_divisor_binary(target_divisor):
			if source_divisor >= target_divisor:
				return Rational.__divide_numerator(numerator, (source_divisor / target_divisor))
			return Rational.__multiply_numerator(numerator, (target_divisor / source_divisor))

		i_numerator = Rational.__multiply_numerator(numerator, target_divisor)

		return Rational.__divide_numerator(i_numerator, source_divisor)

	@classmethod
	def __divide_numerator(cls, numerator, divisor):
		i_divisor = int(divisor)
		if 0 == i_divisor:
			raise ZeroDivisionError()

		i_numerator = int(numerator)
		if 0 != i_numerator and 1 != i_divisor:
			fraction = abs(i_numerator) % abs(i_divisor)
			is_positive = ((i_numerator) >= 0 and (i_divisor >= 0)) or ((i_numerator < 0) and (i_divisor < 0))

			i_numerator //= i_divisor

			if 0 != fraction:
				if is_positive:
					if (2 * fraction) >= abs(i_divisor):
						i_numerator += 1
				else:
					if (2 * fraction) >= abs(i_divisor):
						i_numerator -= 1

		return i_numerator

	@classmethod
	def __multiply_numerator(cls, numerator, multiplier):
		i_numerator = int(numerator)
		i_multiplier = int(multiplier)

		return i_numerator * i_multiplier

	@classmethod
	def __is_divisor_decimal(cls, divisor):
		return (divisor % 10) == 0

	@classmethod
	def __is_divisor_binary(cls, divisor):
		return math.modf(math.log2(divisor))[0] == 0

class TRational:
	TICK_UNCHANGED = 0
	TICK_UP = 1
	TICK_DOWN = 2
	TICK_UNDEFINED = 3

	TREND_UNCHANGED = 0
	TREND_UP = 1
	TREND_DOWN = 2
	TREND_UNDEFINED = 3

	_TICK_TREND_STRINGS = '=+- '

	def __init__(self, tick, trend_on_day, rational):
		self.tick = tick
		self.trend_on_day = trend_on_day
		self.rational = rational

	def to_native(self):
		'''Converts to a float, or returns None for special denominator values'''
		return self.rational.to_native()

	def __str__(self):
		tick_string = TRational._TICK_TREND_STRINGS[self.tick]
		trend_on_day_string = TRational._TICK_TREND_STRINGS[self.trend_on_day]

		return f"{self.rational}<{tick_string}{trend_on_day_string} >"

###############################################################################
# Methods for building field data.
###############################################################################

def _build_date(value):
	if value == datetime.date.min:
		return _c_lib.C_FieldValueDate(0, 1, 0)
	elif value == datetime.date.max:
		return _c_lib.C_FieldValueDate(31, 12, 32767)
	else:
		return _c_lib.C_FieldValueDate(value.day, value.month, value.year)

def _build_time(value):
	if isinstance(value, Time):
		return _c_lib.C_FieldValueTime(value.resolution, value.seconds_in_day, value.sub_second)
	else:
		seconds_in_day = value.hour * 3600 + value.minute * 60 + value.second
		return _c_lib.C_FieldValueTime(Time.RESOLUTION_MICROSECOND, seconds_in_day, value.microsecond)

def _build_date_time(value):
	if isinstance(value, DateTime):
		return _c_lib.C_FieldValueDateTime(_build_date(value.date), _build_time(value.time))
	elif value == datetime.datetime.min:
		return _c_lib.C_FieldValueDateTime(_c_lib.C_FieldValueDate(0, 1, 0), _c_lib.C_FieldValueTime(Time.RESOLUTION_SECOND, 0, 0))
	elif value == datetime.datetime.max:
		return _c_lib.C_FieldValueDateTime(_c_lib.C_FieldValueDate(31, 12, 32767),
										   _c_lib.C_FieldValueTime(Time.RESOLUTION_SECOND, 86399, 0))
	else:
		return _c_lib.C_FieldValueDateTime(_build_date(value.date()), _build_time(value.time()))

def _build_field_value(field_type, value, cached_values):
	if field_type == constants.FIELD_TYPE_DATE:
		return _build_date(value)
	elif field_type == constants.FIELD_TYPE_TIME:
		return _build_time(value)
	elif field_type == constants.FIELD_TYPE_DATE_TIME:
		return _build_date_time(value)
	elif field_type == constants.FIELD_TYPE_SINT:
		return _c_lib.c_int64(value)
	elif field_type == constants.FIELD_TYPE_UINT:
		return _c_lib.c_uint64(value)
	elif field_type == constants.FIELD_TYPE_RATIONAL:
		return _c_lib.C_FieldValueRational(value.denominator, value.numerator)
	elif field_type == constants.FIELD_TYPE_TRATIONAL:
		rational = _c_lib.C_FieldValueRational(value.rational.denominator, value.rational.numerator)
		return _c_lib.C_FieldValueTRational(value.tick, value.trend_on_day, rational)

	elif (field_type == constants.FIELD_TYPE_TEXT_ARRAY or
		  field_type == constants.FIELD_TYPE_TEXT_STRING):

		encoded_data = value.encode()
		cached_values.append(encoded_data)
		return _c_lib.C_FieldValueBuffer(_c_lib.cast(encoded_data, _c_lib.POINTER(_c_lib.c_uint8)), len(value))

	elif (field_type == constants.FIELD_TYPE_BINARY_STRING or
			field_type == constants.FIELD_TYPE_BINARY_ARRAY or
			field_type == constants.FIELD_TYPE_BLOB or
			field_type == constants.FIELD_TYPE_CRC_BLOB):

		return _c_lib.C_FieldValueBuffer(_c_lib.cast(value, _c_lib.POINTER(_c_lib.c_uint8)), len(value))

	elif field_type == constants.FIELD_TYPE_DOUBLE:
		return _c_lib.c_double(value)
	elif field_type == constants.FIELD_TYPE_BOOLEAN:
		return _c_lib.c_bool(value)
	else:
		raise RuntimeError(f"unsupported field type {field_type}")

def _build_field_data(session, fields):
	field_data_list = []
	cached_values = []

	data_source = session.parameters[constants.FID_SESSION_PUBLISH_DATA_SOURCE]
	dictionary = session.metadata.get_data_source_dictionary(data_source)

	for (field_id, value) in fields.items():
		if field_id > 16383:
			raise RuntimeError('field id > 16383 is not supported')

		if value is None:
			field_data_list.append(_c_lib.C_FieldData(field_id, 0, True, None))
			continue

		if not (field_id in dictionary.field_map):
			raise RuntimeError(f"field id {field_id} is not present in dictionary {dictionary.id}")

		field_info = dictionary.field_map[field_id]

		built_value = _build_field_value(field_info.type, value, cached_values)
		field_data = _c_lib.C_FieldData(field_id, field_info.type, True, _c_lib.cast(_c_lib.byref(built_value), _c_lib.c_void_p))
		field_data_list.append(field_data)

		# The values built and cast to void pointers must not be garbage collected until they have been used.
		cached_values.append(built_value)

	return (field_data_list, cached_values)
