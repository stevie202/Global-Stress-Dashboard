class DataSource:
	def __init__(self, msg):
		self.id = msg.id
		self.name = msg.name.decode()
		self.symbology_id = msg.symbology_id
		self.dictionary_id = msg.dictionary_id

class Symbology:
	def __init__(self, msg):
		self.id = msg.id
		self.name = msg.name.decode()

class Field:
	def __init__(self, msg):
		self.id = msg.field_id
		self.name = msg.name.decode()
		self.type = msg.type

class Dictionary:
	def __init__(self, msg):
		self.id = msg.id
		self.name = msg.name.decode()

		self.field_map = {}
		self.field_name_map = {}

		for i in range(0, msg.field_count):
			field = Field(msg.fields[i])
			self.field_map[field.id] = field
			self.field_name_map[field.name] = field

	def get_field(self, field_id):
		return self.field_map[field_id]

	def get_field_name(self, field_id):
		'''Get the name for a field id or return the field id as a string if not found.'''
		if field_id in self.field_map:
			return self.field_map[field_id].name

		return str(field_id)

class Metadata:
	def __init__(self):
		self.data_source_map = {}
		self.symbology_map = {}
		self.dictionary_map = {}

	def get_data_source(self, id):
		return self.data_source_map[id]

	def get_symbology(self, id):
		return self.symbology_map[id]

	def get_dictionary(self, id):
		return self.dictionary_map[id]

	def get_data_source_name(self, id):
		'''Get the name of a data source or return the number as a string if not found.'''
		if id in self.data_source_map:
			return self.data_source_map[id].name

		return str(id)

	def get_symbology_name(self, id):
		'''Get the name of a symbology or return the number as a string if not found.'''
		if id in self.symbology_map:
			return self.symbology_map[id].name

		return str(id)

	def get_dictionary_name(self, id):
		'''Get the name of a symbology or return the number as a string if not found.'''
		if id in self.dictionary_map:
			return self.dictionary_map[id].name

		return str(id)

	def get_data_source_id(self, name):
		'''Get the id of a data source by name, raise exception if not found.'''
		for value in self.data_source_map.values():
			if name == value.name:
				return value.id

		raise RuntimeError(f'Data source {name} not found')

	def get_symbology_id(self, name):
		'''Get the id of a symbology by name, raise exception if not found.'''
		for value in self.symbology_map.values():
			if name == value.name:
				return value.id

		raise RuntimeError(f'Symbology {name} not found')

	def get_dictionary_id(self, name):
		'''Get the id of a dictionary by name, raise exception if not found.'''
		for value in self.dictionary_map.values():
			if name == value.name:
				return value.id

		raise RuntimeError(f'Dictionary {name} not found')

	def get_data_source_dictionary(self, data_source_id):
		'''Get the dictionary for a data source, raise exception if not found.'''
		data_source = self.data_source_map[data_source_id]
		return self.dictionary_map[data_source.dictionary_id]

	def get_field_name(self, data_source_id, field_id):
		'''Get the name of a field id (and data source id) or return the field id as a string if not found.'''
		if not (data_source_id in self.data_source_map):
			return str(field_id)

		data_source = self.data_source_map[data_source_id]

		if not (data_source.dictionary_id in self.dictionary_map):
			return str(field_id)

		return self.dictionary_map[data_source.dictionary_id].get_field_name(field_id)

	def _update(self, msg):
		for i in range(0, msg.data_source_count):
			data_source = DataSource(msg.data_sources[i])
			self.data_source_map[data_source.id] = data_source

		for i in range(0, msg.symbology_count):
			symbology = Symbology(msg.symbologies[i])
			self.symbology_map[symbology.id] = symbology

		for i in range(0, msg.dictionary_count):
			dictionary = Dictionary(msg.dictionaries[i])
			self.dictionary_map[dictionary.id] = dictionary
