#!/bin/env python3

# This sample demonstrates how to make and process the results of an asynchronous query.

from activfinancial import *
from activfinancial.constants import *

import common

# The results of our asynchronous query will be presented by the
# callbacks of this QueryHandler class.
class QueryHandler:
	def on_query_add(self, msg, context):
		print(f'ADD received for {msg.symbol}')

	def on_query_remove(self, msg, context):
		print(f'REMOVE received for {msg.symbol}')

	def on_query_status(self, msg, context):
		error_string = f' ({status_code_to_string(msg.status_code)})' if (msg.is_error() or msg.is_failure()) else ''
		print(f'QUERY STATUS {query_state_to_string(msg.state)}{error_string} for {msg.query}')

		if msg.is_complete() or msg.is_failure():
			Session.shutdown(context.session)

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session = Session({ FID_ENABLE_CTRL_HANDLER: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create an asynchronous query for all Canadian Solar Inc US Equity topics.
session.query("type=listing and country=US and symbol=CSIQ.*", handler=QueryHandler())

# Run the internal session message loop.
session.run()
