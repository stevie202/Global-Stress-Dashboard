#!/bin/env python3

# This sample demonstrates how to interface with the Time Series Server.

from activfinancial import *
from activfinancial.constants import *

import common

from datetime import date, datetime, timedelta

# Create the session.
# Enable time series requests.
session = Session({ FID_SESSION_ENABLE_TIME_SERIES: True } )

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Ticks: get the last 10 trade ticks for the Canadian Solar Inc US Equity topic.
msgs = session.time_series_ticks("CSIQ.Q", start=datetime.max,
								count=-10, filter="trades")

# Intraday bars: get 5 minute bars for the last 24 hours for the Canadian Solar Inc US Equity topic.
#msgs = session.time_series_intraday_bars("CSIQ.Q", utc=True, interval="5m",
#										 start=datetime.utcnow() - timedelta(days=1), end=datetime.max)

# History bars: Get the last week's daily bars for Canadian Solar Inc US Equity topic.
#msgs = session.time_series_history_bars("CSIQ.Q", interval="daily",
#										start=date.today() - timedelta(days=7), end=date.max)

for msg in msgs:
	print(f'TIME SERIES MESSAGE received for {msg.symbol}')
	print(common.time_series_message_to_string(msg, session.metadata))
