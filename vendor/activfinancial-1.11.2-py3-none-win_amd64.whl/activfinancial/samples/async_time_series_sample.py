#!/bin/env python3

# This sample demonstrates how to interface with the Time Series Server.

from activfinancial import *
from activfinancial.constants import *

import common

from datetime import date, datetime, timedelta

# This TimeSeriesHandler class provides us with an interface for processing
# the result of our time series request.
class TimeSeriesHandler:
	def __init__(self):
		self.complete = False

	def on_time_series_message(self, msg, context):
		self.complete = msg.complete
		print(f'TIME SERIES MESSAGE received for {msg.symbol}')
		print(common.time_series_message_to_string(msg, context.session.metadata))

	def on_time_series_failure(self, msg, context):
		self.complete = msg.complete
		print(f'TIME SERIES FAILURE for {msg.symbol}')
		print(common.time_series_failure_message_to_string(msg))

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
# Enable time series requests.
session = Session({ FID_ENABLE_CTRL_HANDLER: True,
				    FID_SESSION_ENABLE_TIME_SERIES: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create the handler to receive the callbacks.
handler = TimeSeriesHandler()

# Ticks: get the last 10 trade ticks for the Canadian Solar Inc US Equity topic.
handle = session.time_series_ticks("CSIQ.Q", handler=handler,
								   start=datetime.max, count=-10, filter="trades")

# Intraday bars: get 5 minute bars for the last 24 hours for the Canadian Solar Inc US Equity topic.
#handle = session.time_series_intraday_bars("CSIQ.Q", handler=handler, utc=True,
#										    start=datetime.utcnow() - timedelta(days=1), end=datetime.max, interval="5m")

# History bars: Get the last week's daily bars for Canadian Solar Inc US Equity topic.
#handle = session.time_series_history_bars("CSIQ.Q", handler=handler,
#										   start=date.today() - timedelta(days=7), end=date.max, interval="daily")

# Keep processing until all results are received or until an error occurs.
try:
	while not handler.complete:
		session.process()
finally:
	handle.close()
