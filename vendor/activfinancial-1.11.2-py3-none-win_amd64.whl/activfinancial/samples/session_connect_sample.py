#!/bin/env python3

# This sample demonstrates how to connect to a Gateway.

from activfinancial import *
from activfinancial.constants import *

# The Session will report its status via the callbacks provided
# by this SessionHandler class. Note that 'on_session_connect'
# is only invoked upon connecting asynchronously.
class SessionHandler:
	def on_session_connect(self, session):
		print('on_session_connect')

	def on_session_disconnect(self, session):
		print('on_session_disconnect')

	def on_session_error(self, session, status_code):
		print(f'on_session_error: {status_code_to_string(status_code)}')

	def on_session_log_message(self, session, log_type, msg):
		print(f'on_session_log_message ({log_type_to_string(log_type)}): {msg}')

# Create a Session callback handler.
session_handler = SessionHandler()

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK..
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True
}

# Construct the Session with a default configuration passing in our SessionHandler.
session = Session(session_parameters, session_handler)

# The host or user credentials can be set here.
#
# Alternatively use the environment variables:
#   ACTIV_SESSION_HOST
#   ACTIV_SESSION_USER_ID
#   ACTIV_SESSION_PASSWORD

connect_parameters = session.get_parameters()

#connect_parameters[FID_HOST]     = 'host'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously with a 10 second timeout.
session.connect(connect_parameters, 10000)

# Alternatively an asynchronous connection can be used
# Connection completion is notified via SessionHandler.on_session_connect()
#session.async_connect(connect_parameters).

# Run the internal session message loop.
session.run()
