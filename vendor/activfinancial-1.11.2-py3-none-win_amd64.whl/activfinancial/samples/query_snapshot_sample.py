#!/bin/env python3

# This sample demonstrates the synchronous use of query_snapshot.

from activfinancial import *
from activfinancial.constants import *

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Request snapshot for all Canadian Solar Inc US Equity options.
(msgs, failures) = session.query_snapshot("symbol=CSIQ. navigate=option")

# Print out the list of symbols that successful snapshots have been received for.
for msg in msgs:
    print(f"SNAPSHOT received for {msg.symbol}")

# Print out the list of symbols that failed.
for failure in failures:
    print(f"SNAPSHOT FAILURE for {failure.symbol}")
