#!/bin/env python3

# This sample demonstrates the use of query_subscribe.

from activfinancial import *
from activfinancial.constants import *

import common

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session = Session({ FID_ENABLE_CTRL_HANDLER: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Request subscription for all Canadian Solar Inc US Equity topics.
# Returned Handle is ignored as the application will exit.
session.query_subscribe("type=listing and country=US and symbol=CSIQ.*",
                        handler=common.PrintSubscriptionHandler())

# Run the internal session message loop.
session.run()
