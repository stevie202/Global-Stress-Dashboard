#!/bin/env python3

# This sample demonstrates how to request a snapshot for a specific set of fields.

from activfinancial import *
from activfinancial.constants import *
from activfinancial.market_data import FID_BID, FID_ASK

import common

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Snapshot Biid/Ask for the Canadian Solar Inc US Equity topic.
# Returns a SnapshotMessage.
msg = session.snapshot("CSIQ.Q", fields=[FID_BID, FID_ASK])

# Field names can also be used.
#msg = session.snapshot("CSIQ.Q", fields=["Bid", "Ask"])

print(f'SNAPSHOT received for {msg.symbol}')
print(common.snapshot_message_to_string(msg, session.metadata))
