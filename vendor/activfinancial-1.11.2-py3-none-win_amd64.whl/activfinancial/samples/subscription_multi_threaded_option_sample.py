#!/bin/env python3

# This sample demonstrates how multiple threads can be used to make several queries for sets of options topics, subscribe to them,
# and process their results simultaneously.

from activfinancial import *
from activfinancial.constants import *

import time
import threading

from common import safe_print

# ----------------------------------------------------------------------------------------------------------------------------------

class TopicDetails:
	def __init__(self):
		self.handle = None
		self.state  = None

# ----------------------------------------------------------------------------------------------------------------------------------

class NamedSession(Session):
	def __init__(self, name, parameters, handler):
		super().__init__(parameters, handler)
		self.name = name

# ----------------------------------------------------------------------------------------------------------------------------------

class SessionHandler:
	def on_session_connect(self, session):
		safe_print(f'{session.name}: on_session_connect')

	def on_session_disconnect(self, session):
		safe_print(f'{session.name}: on_session_disconnect')

	def on_session_error(self, session, status_code):
		safe_print(f'{session.name}: on_session_error: {status_code_to_string(status_code)}')

	def on_session_log_message(self, session, log_type, msg):
		safe_print(f'{session.name}: on_session_log_message ({log_type_to_string(log_type)}): {msg}')

# ----------------------------------------------------------------------------------------------------------------------------------

class OptionChainSubscriptionHandler:
	def __init__(self):
		self.subscription_map = {}

	# QueryHandler Callbacks
	def on_query_add(self, msg, context):
		safe_print(f'ADD received for {msg.symbol}')

		topic_details = self.subscription_map.get(msg.symbol)
		if topic_details == None:
			topic_details           = TopicDetails()
			topic_details.state     = TOPIC_SUBSCRIPTION_STATE_PENDING
			topic_details.handle    = context.session.subscribe(msg.symbol, handler=self)

			self.subscription_map[msg.symbol] = topic_details

	def on_query_remove(self, msg, context):
		safe_print(f'REMOVE received for {msg.symbol}')

		try:
			topic_details = self.subscription_map[msg.symbol]
			del topic_details
		except KeyError:
			pass

	def on_query_status(self, msg, context):
		error_string = f' ({status_code_to_string(msg.status_code)})' if (msg.is_error() or msg.is_failure()) else ''
		print(f'QUERY STATUS {query_state_to_string(msg.state)}{error_string} for {msg.query}')

	# SubscriptionHandler Callbacks
	def on_subscription_refresh(self, msg, context):
		safe_print(f'{context.session.name}: REFRESH received for {msg.symbol}')

	def on_subscription_update(self, msg, context):
		safe_print(f'{context.session.name}: UPDATE received for {msg.symbol}')

	def on_subscription_topic_status(self, msg, context):
		safe_print(f'TOPIC STATUS received for {msg.symbol} {topic_subscription_state_to_string(msg.topic_subscription_state)}')
		self.subscription_map[msg.symbol].state = msg.topic_subscription_state

	def on_subscription_status(self, msg, context):
		output = f'{context.session.name}: STATUS received for {msg.request} {subscription_state_to_string(msg.state)}'
		if msg.is_error() or msg.is_failure():
			output += f' ({status_code_to_string(msg.status_code)})'
		
		safe_print(output)

# ----------------------------------------------------------------------------------------------------------------------------------

class WorkerSessionHandler(SessionHandler):
	def on_session_user_message(self, session, msg):
		query = msg.decode('utf-8')
		# Handles can be ignored if there is no intention to unsubscribe.
		session.query(query, handler=OptionChainSubscriptionHandler())
		safe_print(f'{session.name}: subscribed to {query}')

# ----------------------------------------------------------------------------------------------------------------------------------

class WorkerThread(threading.Thread):
	def __init__(self, name, connect_parameters):
		self.connect_parameters = connect_parameters
		self.session			= NamedSession(name, {}, WorkerSessionHandler())

		super().__init__()
		self.start()

	def run(self):
		# Connect to session.
		self.session.connect(self.connect_parameters)
		# Run session.
		self.session.run()

# ----------------------------------------------------------------------------------------------------------------------------------

# The number of worker threads
thread_count = 2

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True
}

# Construct the Session, passing in our SessionHandler.
session = NamedSession('Main Thread', session_parameters, SessionHandler())

# The host or user credentials can be set here.
#
# Alternatively use the environment variables:
#   ACTIV_SESSION_HOST
#   ACTIV_SESSION_USER_ID
#   ACTIV_SESSION_PASSWORD

connect_parameters = session.get_parameters()

#connect_parameters[FID_HOST]     = 'host'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create worker threads. They will be running once the constructor completes.
worker_thread_list = []
for i in range(thread_count):
	worker_thread_list.append(WorkerThread(f'Thread {i}', connect_parameters))

# Option root queries.
option_root_query_list = [
	"type=option and country=US and symbol=CSIQ/* and exchange=O",
	"type=option and country=US and symbol=PKG/* and exchange=O"
]

# Distribute topics across subscription threads.
thread_index = -1
for query in option_root_query_list:
	thread_index = (thread_index + 1) % thread_count
	Session.post_user_message(worker_thread_list[thread_index].session, bytes(query, 'utf-8'))

# Run the internal session message loop.
session.run()
for worker in worker_thread_list:
	worker.join()

# The CTRL handler (FID_ENABLE_CTRL_HANDLER), will cause all Sessions to end.
