#!/bin/env python3

# This sample demonstrates the use of ExchangeInfoHelper.

from activfinancial import *
from activfinancial.constants import *
from activfinancial.market_data.exchange_info_helper import *

import datetime

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

with ExchangeInfoHelper(session) as helper:
	while helper.state != ExchangeInfoHelper.STATE_OK:
		if STATUS_CODE_EXIT == session.process():
			break
		if helper.state == ExchangeInfoHelper.STATE_ERROR:
			raise RuntimeError('Exchange info helper error')

# Exchange info can be queried using a symbol with exchange code.
symbol = "CSIQ.Q"
exchange_info = helper.get_exchange_info(symbol)
print(f'{symbol}: exchange {exchange_info.name} ({exchange_info.symbol}), timezone {exchange_info.timezone}')

# A composite symbol uses "US" as the exchange code because that cannot be empty.
symbol = "CSIQ."
exchange_info = helper.get_exchange_info(symbol)
print(f'{symbol}: exchange {exchange_info.name} ({exchange_info.symbol}), timezone {exchange_info.timezone}')

# Exchange info can also be queried using just an exchange code.
symbol = "Q"
exchange_info = helper.get_exchange_info(symbol)
print(f'{symbol}: exchange {exchange_info.name} ({exchange_info.symbol}), timezone {exchange_info.timezone}')
print(exchange_info.convert_date_time_to_utc(datetime.date.today(), datetime.datetime.now()))
