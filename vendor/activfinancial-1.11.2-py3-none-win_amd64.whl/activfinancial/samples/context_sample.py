#!/bin/env python3
from activfinancial import *
from activfinancial.constants import *

# This sample demonstrates how to create a request (in this case a subscription) with associated user data, and how that user data
# can be manipulated by the associated request handler.

import common

# Use the Subscription Handler defined in common.py as a base for our
# own Subscription Handler, and override 'on_subscription_update', so
# we may tailor it for this particular example.
class SubscriptionHandler(common.PrintSubscriptionHandler):
	def on_subscription_update(self, msg, context):
		print(f'UPDATE received for {msg.symbol}')

		# Increment the update count on each update received.
		context.user_data.update_count += 1

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session = Session({ FID_ENABLE_CTRL_HANDLER: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Variable to hold subscription update count.
user_data = type('', (), {})
user_data.update_count = 0

# Subscription callback handler.
subscription_handler = SubscriptionHandler()

# Request subscription of the Canadian Solar Inc US Equity topic. Pass our map containing the update count so it can
# be accessed in the handler object.
subscribe_handle = session.subscribe("CSIQ.Q", handler=subscription_handler, user_data=user_data)

# Run the internal session message loop.
session.run()

# Close the handle to end the subscription.
subscribe_handle.close()

# Print the final update count after ending the Session.
print(f'Received {user_data.update_count} updates')
