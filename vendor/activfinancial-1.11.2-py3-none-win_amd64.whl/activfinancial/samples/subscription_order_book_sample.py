#!/bin/env python3

# This sample demonstrates how to make a subscription to an order book topic and how one might choose to process the results.
# Specifically, this program keeps track of the number of 'buy orders' and 'sell orders' currently in the book, and prints that
# information to the console every second.

from activfinancial import *
from activfinancial.constants import *
from activfinancial.market_data import FID_ORDER_BUY_SELL

import time

import common

# Use the Subscription Handler defined in common.py as a base for our
# own Subscription Handler, overriding 'on_subscription_refresh',
# 'on_subscription_update' and the constructor, and adding additional
# methods and members so it may be tailored to the needs of this sample.
class SubscriptionHandler(common.PrintSubscriptionHandler):
	def __init__(self):
		super().__init__()
		self.order_entry_map  = {}
		self.buy_order_count  = 0
		self.sell_order_count = 0

	def display_order_count(self):
		print(f'Buy order count: {self.buy_order_count} | Sell order count: {self.sell_order_count}')

	def is_sell_order(self, msg):
		order_type = msg.fields[FID_ORDER_BUY_SELL].value
		return ('S' == order_type)

	def on_subscription_refresh(self, msg, context):
		# Ignore refresh of common fields
		if msg.map_key is None:
			return

		self.order_entry_map[msg.map_key] = msg

		if self.is_sell_order(msg):
			self.sell_order_count += 1
		else:
			self.buy_order_count  += 1

	def on_subscription_update(self, msg, context):
		if msg.update_type == UPDATE_TYPE_MAP_ADD:
			self.order_entry_map[msg.map_key] = msg

			if self.is_sell_order(msg):
				self.sell_order_count += 1
			else:
				self.buy_order_count  += 1

		elif msg.update_type == UPDATE_TYPE_MAP_REMOVE:
			try:
				order = self.order_entry_map[msg.map_key]

				if self.is_sell_order(order):
					self.sell_order_count -= 1
				else:
					self.buy_order_count  -= 1

				del order
			except KeyError:
				pass

		elif msg.update_type == UPDATE_TYPE_MAP_UPDATE:
			self.order_entry_map[msg.map_key] = msg

		else:
			pass
	
	def on_subscription_status(self, msg, context):
		output = f'SUBSCRIPTION STATUS received for {msg.request} {subscription_state_to_string(msg.state)}'
		if msg.is_error() or msg.is_failure():
			output += f' ({status_code_to_string(msg.status_code)})'
		
		print(output)

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
# Use DATA_SOURCE_ACTIV_LOW_LATENCY by default.
session = Session({ FID_ENABLE_CTRL_HANDLER: True,
				    FID_DATA_SOURCE: DATA_SOURCE_ACTIV_LOW_LATENCY },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create a Subscription Handler.
subscription_handler = SubscriptionHandler()

# Request subscription of the Canadian Solar Inc US Equity order book topic.
session.subscribe('CSIQ.EA-MBO', handler=subscription_handler)

# Prints buy and sell order count every second.
last = time.monotonic()
while STATUS_CODE_EXIT != session.process():
	current = time.monotonic()
	elapsed = current - last
	if elapsed >= 1:
		subscription_handler.display_order_count()
		last = time.monotonic()
