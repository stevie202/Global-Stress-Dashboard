#!/bin/env python3

# This sample demonstrates how to make a query for a set of options topics, subscribe to them, and process their results.

from activfinancial import *
from activfinancial.constants import *

import common

class TopicDetails:
	def __init__(self):
		self.handle = None
		self.state  = None

class OptionChainSubscriptionHandler:
	def __init__(self):
		self.subscription_map = {}

	# QueryHandler Callbacks
	def on_query_add(self, msg, context):
		print(f'ADD received for {msg.symbol}')

		topic_details = self.subscription_map.get(msg.symbol)
		if topic_details == None:
			topic_details           = TopicDetails()
			topic_details.state     = TOPIC_SUBSCRIPTION_STATE_PENDING
			topic_details.handle    = context.session.subscribe(msg.symbol, handler=self)

			self.subscription_map[msg.symbol] = topic_details

	def on_query_remove(self, msg, context):
		print(f'REMOVE received for {msg.symbol}')

		try:
			topic_details = self.subscription_map[msg.symbol]
			del topic_details
		except KeyError:
			pass

	def on_query_status(self, msg, context):
		error_string = f' ({status_code_to_string(msg.status_code)})' if (msg.is_error() or msg.is_failure()) else ''
		print(f'QUERY STATUS {query_state_to_string(msg.state)}{error_string} for {msg.query}')

	# SubscriptionHandler Callbacks
	def on_subscription_refresh(self, msg, context):
		print(f'REFRESH received for {msg.symbol}')

	def on_subscription_update(self, msg, context):
		print(f'UPDATE received for {msg.symbol}')

	def on_subscription_topic_status(self, msg, context):
		print(f'TOPIC STATUS received for {msg.symbol} {topic_subscription_state_to_string(msg.topic_subscription_state)}')
		self.subscription_map[msg.symbol].state = msg.topic_subscription_state

	def on_subscription_status(self, msg, context):
		output = f'SUBSCRIPTION STATUS received for {msg.request} {subscription_state_to_string(msg.state)}'
		if msg.is_error() or msg.is_failure():
			output += f' ({status_code_to_string(msg.status_code)})'
		
		print(output)

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session = Session({ FID_ENABLE_CTRL_HANDLER: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create a query for all Canadian Solar Inc US Equity topics.
session.query("type=option and country=US and symbol=CSIQ/* and exchange=Q", handler=OptionChainSubscriptionHandler())

# Run the internal session message loop.
session.run()
