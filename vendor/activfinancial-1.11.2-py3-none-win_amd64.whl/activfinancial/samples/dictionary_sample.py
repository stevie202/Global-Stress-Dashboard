#!/bin/env python3

# This sample demonstrates how to configure a session to download dictionaries.

from activfinancial import *
from activfinancial.constants import *

# Short function to make the output prettier.
def format_field(field):
	return f'{field.id:<5}{field.name:<50}{field_type_to_string(field.type)}'

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Get the ACTIV dictionary.
dictionary = session.metadata.get_dictionary(DICTIONARY_ACTIV)

# Print out the details of each Field held by the dictionary.
for (fid, field) in dictionary.field_map.items():
	print(format_field(field))
