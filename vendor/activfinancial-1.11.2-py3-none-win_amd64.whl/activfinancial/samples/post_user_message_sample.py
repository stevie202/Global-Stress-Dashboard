#!/bin/env python3

# This sample demonstrates how user messages can be used to perform local communication with a session during runtime.

from activfinancial import *
from activfinancial.constants import *

import time
import threading

import common

# Use the Subscription Handler defined in common.py as a base for our
# own Subscription Handler, and implement 'on_session_user_message'.
class SessionHandler(common.PrintSessionHandler):
	def on_session_user_message(self, session, msg):
		count = int.from_bytes(msg, 'big')
		print(f'Received message: {count}')

		if count == 0:
			Session.shutdown(session)

# Process thread method.
def process_thread(session):
	msg = 3
	while msg >= 0:
		time.sleep(1)
		Session.post_user_message(session, msg.to_bytes(msg, 'big'))
		msg -= 1

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True
}

# Construct the Session with a default configuration passing in our SessionHandler.
session = Session(session_parameters, SessionHandler())

# Create and start the thread which will post the user messages.
message_thread = threading.Thread(target=process_thread, args=(session,))
message_thread.start()

# Run the internal session message loop.
session.run()

# Join message thread.
message_thread.join()
