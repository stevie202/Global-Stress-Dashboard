#!/bin/env python3

# This sample demonstrates how navigations can be used with queries.

from activfinancial import *
from activfinancial.constants import *

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Make a query for the company record of Canadian Solar Inc.
# Returns a list of QueryAddMessage objects.
msgs = session.query('symbol=CSIQ.Q navigate=company')
for msg in msgs:
	print(f"Navigation result: {msg.symbol}")
