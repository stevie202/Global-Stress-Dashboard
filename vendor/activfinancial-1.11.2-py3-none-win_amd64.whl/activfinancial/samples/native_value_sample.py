#!/bin/env python3

# This sample demonstrates how to convert values to native python types.

from activfinancial import *
from activfinancial.constants import *

import common

symbol = 'CSIQ.Q'

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

print(f"Requesting snapshot for {symbol}...")

msg = session.snapshot(symbol)

common.print_field('Symbol', msg.symbol)
common.print_field('PermissionId', msg.permission_id)
common.print_field('UpdateId', msg.update_id)
print()

for (fid, value) in msg.fields.items():
	field_name = session.metadata.get_field_name(msg.data_source_id, fid)
	if value.is_defined():
		native_value = value.to_native()
		common.print_field(field_name, f"{str(native_value):20} (type {type(native_value).__name__})")
	else:
		common.print_field(field_name, 'undefined')
