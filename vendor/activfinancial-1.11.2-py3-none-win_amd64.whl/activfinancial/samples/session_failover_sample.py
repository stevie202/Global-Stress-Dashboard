#!/bin/env python3

# This sample demonstrates how to failover between gateways.

from activfinancial import *
from activfinancial.constants import *

import time

# Manages failover between different gateways.
#
# The user should not call the session connect/disconnect methods while using this class.
class FailoverHelper:

	# Failover after 15 seconds with a connection down.
	FAILOVER_TIMEOUT = 15

	def __init__(self, session, connect_parameters, host_list):
		self.session = session
		self.connect_parameters = dict(connect_parameters)
		self.host_list = list(host_list)
		self.is_active = False
		self.failover_start_timestamp = 0.0
		
		# Use the first host in the list.
		self.connect_parameters[FID_HOST] = host_list[0]

	# Synchronously connect to the platform.
	def connect(self, timeout):
		if self.is_active:
			raise RuntimeError('wrong state')

		first_host = self.get_host()
		
		while True:
			try:
				self.connect_parameters[FID_HOST] = self.get_host()
				self.session.connect(self.connect_parameters, timeout)
				
				self.is_active = True
				self.failover_start_timestamp = time.monotonic()

				return

			except:
				self._next_host()
				
				if self.get_host() == first_host:
					raise

	# Asynchronously connect to the platform.
	def async_connect(self):
		if self.is_active:
			raise RuntimeError('wrong state')

		self._async_connect()
		self.is_active = True

	# Disconnect from the platform.
	def disconnect(self):
		if not self.is_active:
			raise RuntimeError('wrong state')

		self.is_active = False

		if SESSION_STATE_W4_DISCONNECT != self.session.get_state() and SESSION_STATE_DISCONNECTED != self.session.get_state():
			self.session.disconnect()

	# Check the failover state, this must be called regularly to drive failover.
	def check_state(self):
		session_state = session.get_state()

		if SESSION_STATE_CONNECTED == session_state:
			# Update the timestamp whilst connected, this means that on a break the current host will be retried.
			self.failover_start_timestamp = time.monotonic()
		elif SESSION_STATE_DISCONNECTED == session_state and self.is_active:
			# Disconnect complete, failover to next host and connect again.
			self._next_host()
			self._async_connect()
		elif SESSION_STATE_W4_DISCONNECT != session_state and self.is_active:
			# Check the failover timestamp.
			if time.monotonic() < self.failover_start_timestamp + FailoverHelper.FAILOVER_TIMEOUT:
				return

			# Failover! Initiate disconnect, reconnect when complete.
			self.session.disconnect()

	# Get the current host.
	def get_host(self):
		return self.host_list[0]

	def _async_connect(self):
		self.connect_parameters[FID_HOST] = self.get_host()
		self.session.async_connect(self.connect_parameters)

		self.failover_start_timestamp = time.monotonic()

	def _next_host(self):
		self.host_list.append(self.host_list.pop(0))

# The Session will report its status via the callbacks provided
# by this SessionHandler class. Note that 'on_session_connect'
# is only invoked upon connecting asynchronously.
class SessionHandler:
	def on_session_connect(self, session):
		print(f'on_session_connect ({session.get_parameters()[FID_HOST]})')

	def on_session_disconnect(self, session):
		print(f'on_session_disconnect ({session.get_parameters()[FID_HOST]})')

	def on_session_error(self, session, status_code):
		print(f'on_session_error ({session.get_parameters()[FID_HOST]}): {status_code_to_string(status_code)}')

	def on_session_log_message(self, session, log_type, msg):
		print(f'on_session_log_message ({session.get_parameters()[FID_HOST]}, {log_type_to_string(log_type)}): {msg}')

# Create a Session callback handler.
session_handler = SessionHandler()

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK..
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True
}

# Construct the Session with a default configuration passing in our SessionHandler.
session = Session(session_parameters, session_handler)

# The user credentials can be set here.
#
# Alternatively use the environment variables:
#   ACTIV_SESSION_USER_ID
#   ACTIV_SESSION_PASSWORD

connect_parameters = session.get_parameters()

#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Configure hosts.
host_list = [ 'localhost', 'aop-replay.activfinancial.com' ]

# Create a failover helper to manage failover.
failover_helper = FailoverHelper(session, connect_parameters, host_list)

# Connect synchronously with a 10 second timeout.
failover_helper.connect(10000)

# Run the session message loop.
while STATUS_CODE_EXIT != session.process():
	failover_helper.check_state()
