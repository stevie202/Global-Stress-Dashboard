#!/bin/env python3

# This sample demonstrates how to search for available symbols using a
# synchronous query.

from activfinancial import *
from activfinancial.constants import *

# Create the session.
session = Session()

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Query for all Canadian Solar Inc US Equity topics.
# Returns a list of QueryAddMessage objects.
msgs = session.query("type=listing and country=US and symbol=CSIQ.*")

for msg in msgs:
    print(f"Symbol: {msg.symbol}")
