#!/bin/env python3

# This sample demonstrates how to register a set of subscription parameters with a session and how those parameters can be used to
# configure the behaviour of subscriptions made through that session. In this case, the subscription is configured to only include trade events.

from activfinancial import *
from activfinancial.constants import *
from activfinancial.market_data import EVENT_TYPE_TRADE

import common

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session = Session({ FID_ENABLE_CTRL_HANDLER: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Set up subscription parameters to only include trade events.
event_list = [
	EVENT_TYPE_TRADE
]

subscription_parameters = {
	FID_EVENT_TYPE_INCLUDE_FILTER: event_list
}

# Register the parameters. The returned handle manages both the lifetime of the parameters and is used to apply the
# parameters to new subscriptions.
subscription_parameters_handle = session.register_subscription_parameters(subscription_parameters)

# Request subscription of the Canadian Solar Inc US Equity topic.
# Pass in subscription_parameters_handle so that the parameters are used for this subscription.
session.subscribe("CSIQ.Q", handler=common.PrintSubscriptionHandler(),
                  parameters=subscription_parameters_handle)

# Run the internal session message loop.
session.run()
