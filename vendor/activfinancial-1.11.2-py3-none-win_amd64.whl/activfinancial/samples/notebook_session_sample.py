#!/bin/env python3

# This sample demonstrates how to use the NotebookSession's interface.

from activfinancial.constants import field_ids
from activfinancial.notebook_session import NotebookSession

session_parameters = { field_ids.FID_ENABLE_CTRL_HANDLER: True }
session = NotebookSession(session_parameters)

df = session.snapshot("CSIQ.Q")
print(df)

#df = session.query("symbol=CSIQ.* table=0")
#print(df)

#df = session.query_snapshot("symbol=CSIQ.* and table=0", ["Bid", "Ask"])
#print(df)
