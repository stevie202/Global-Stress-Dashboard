#!/bin/env python3

# This sample demonstrates how multiple threads can be used to make several subscriptions and process their results simultaneously.

from activfinancial import *
from activfinancial.constants import *

import time
import threading

from common import safe_print

# ----------------------------------------------------------------------------------------------------------------------------------

class NamedSession(Session):
	def __init__(self, name, parameters, handler):
		super().__init__(parameters, handler)
		self.name = name

# ----------------------------------------------------------------------------------------------------------------------------------

class SessionHandler:
	def on_session_connect(self, session):
		safe_print(f'{session.name}: on_session_connect')

	def on_session_disconnect(self, session):
		safe_print(f'{session.name}: on_session_disconnect')

	def on_session_error(self, session, status_code):
		safe_print(f'{session.name}: on_session_error: {status_code_to_string(status_code)}')

	def on_session_log_message(self, session, log_type, msg):
		safe_print(f'{session.name}: on_session_log_message ({log_type_to_string(log_type)}): {msg}')

# ----------------------------------------------------------------------------------------------------------------------------------

class SubscriptionHandler:
	def on_subscription_refresh(self, msg, context):
		safe_print(f'{context.session.name}: REFRESH received for {msg.symbol}')

	def on_subscription_update(self, msg, context):
		safe_print(f'{context.session.name}: UPDATE received for {msg.symbol}')

	def on_subscription_topic_status(self, msg, context):
		safe_print(f'{context.session.name}: TOPIC STATUS received for {msg.symbol}')

	def on_subscription_status(self, msg, context):
		output = f'{context.session.name}: STATUS received for {msg.request} {subscription_state_to_string(msg.state)}'
		if msg.is_error():
			output += f' ({status_code_to_string(msg.status_code)})'
		
		safe_print(output)

# ----------------------------------------------------------------------------------------------------------------------------------

class WorkerSessionHandler(SessionHandler):
	def on_session_user_message(self, session, msg):
		symbol = msg.decode('utf-8')

		# Handles can be ignored if there is no intention to unsubscribe.
		session.subscribe(symbol, handler=SubscriptionHandler())
		safe_print(f'{session.name}: subscribed to {symbol}')

# ----------------------------------------------------------------------------------------------------------------------------------

class WorkerThread(threading.Thread):
	def __init__(self, name, connect_parameters):
		self.connect_parameters = connect_parameters
		self.session            = NamedSession(name, {}, WorkerSessionHandler())

		super().__init__()
		self.start()

	def run(self):
		# Connect to session.
		self.session.connect(self.connect_parameters)
		# Run session.
		self.session.run()

# ----------------------------------------------------------------------------------------------------------------------------------

# The number of worker threads
thread_count = 3

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True
}

# Construct the Session, passing in our SessionHandler.
session = NamedSession('Main Thread', session_parameters, SessionHandler())

# The host or user credentials can be set here.
#
# Alternatively use the environment variables:
#   ACTIV_SESSION_HOST
#   ACTIV_SESSION_USER_ID
#   ACTIV_SESSION_PASSWORD

connect_parameters = session.get_parameters()

#connect_parameters[FID_HOST]     = 'host'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Make a query in order to acquire the set of symbols which will be subscribed to by the worker threads.
query_result = session.query('type=listing and symbol=CSIQ.*')

# Create worker threads. They will be running once the constructor completes.
worker_thread_list = []
for i in range(thread_count):
	worker_thread_list.append(WorkerThread(f'Thread {i}', connect_parameters))

# Distribute the symbols from the queries amongst the worker threads. The worker threads
# will each subscribe to their set of symbols.
thread_index = -1
for msg in query_result:
	symbol = msg.symbol
	thread_index = (thread_index + 1) % thread_count

	Session.post_user_message(worker_thread_list[thread_index].session, bytes(symbol, 'utf-8'))

# Run the internal session message loop.
session.run()
for worker in worker_thread_list:
	worker.join()

# The CTRL handler (FID_ENABLE_CTRL_HANDLER), will cause all Sessions to end.
