#!/bin/env python3

# This sample demonstrates how to make and process the result of an atomic snapshot request.
# Note that atomic snapshots are not generally available and need to be configured in a dedicated environment.

from activfinancial import *
from activfinancial.constants import *

import common

# This SnapshotHandler class provides us with an interface for processing
# the result of our snapshot request.
class SnapshotHandler:
	def __init__(self):
		self.complete = False

	def on_snapshot(self, msg, context):
		self.complete = msg.complete
		print(f'SNAPSHOT received for {msg.symbol}')
		print(common.snapshot_message_to_string(msg, context.session.metadata))

	def on_snapshot_failure(self, msg, context):
		self.complete = msg.complete
		print(f'SNAPSHOT FAILURE for {msg.symbol}')
		print(common.snapshot_failure_message_to_string(msg))

# Create the session.
# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
# Enable atomic snapshot support in the API. Note that these must also be configured in the domain to be used.
session = Session({ FID_ENABLE_CTRL_HANDLER: True,
				    FID_SESSION_ENABLE_ATOMIC_SNAPSHOT: True },
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

# Create the Snapshot Handler.
snapshot_handler = SnapshotHandler()

# Request snapshot of the GC/29Z.CXA group
# Returned Handle for a Snapshot is only required to cancel the request while it is in progress.
snapshot_handle = session.snapshot("GC/29Z.CXA", handler=snapshot_handler,
								   data_source_id=DATA_SOURCE_ACTIV_ATOMIC_SNAPSHOT)

# Keep processing until the snapshot is retrieved
# or until an error occurs.
try:
	while not snapshot_handler.complete:
		session.process()
finally:
	snapshot_handle.close()

# session.run() will also work here, but will not exit upon retrieval
# of the snapshot as the above method does.
