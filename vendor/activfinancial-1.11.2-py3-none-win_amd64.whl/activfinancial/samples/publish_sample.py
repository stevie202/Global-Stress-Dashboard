#!/bin/env python3

# This sample demonstrates how to publish content.

from activfinancial import *
from activfinancial.constants import *
from activfinancial.field_types import Time
from activfinancial.types import Field

import common

import datetime
import time

# Convenience function for getting the number of seconds which have passed in a day.
def seconds_in_day():
	now = datetime.datetime.now()
	delta = (now - now.replace(hour=0, minute=0, second=0, microsecond=0))

	return int(delta.total_seconds())

# Fields ids.
FID_MESSAGE = 0
FID_VALUE = 1
FID_TIME = 2

# Enable a CTRL handler to exit cleanly on CTRL-C/CTRL-BREAK.
# Configure session for publishing.
session_parameters = {
	FID_ENABLE_CTRL_HANDLER: True,
	FID_SESSION_PUBLISH_MODE: PUBLISH_MODE_PUSH,
	FID_SESSION_PUBLISH_DATA_SOURCE: 5000
}

# Create the session.
session = Session(session_parameters,
				  handler=common.PrintSessionHandler())

connect_parameters = {}
#connect_parameters[FID_HOST]     = 'aop-replay.activfinancial.com'
#connect_parameters[FID_USER_ID]  = 'user id'
#connect_parameters[FID_PASSWORD] = 'password'

# Connect synchronously.
session.connect(connect_parameters)

field_list = {}
last = time.monotonic()
count = 0

# Publish updates for sixty seconds.
while (count < 60):
	current = time.monotonic()
	elapsed = current - last
	if elapsed >= 1:
		count += 1
		last = current

		# Populate fields.
		field_list[FID_MESSAGE] = "Test message"
		field_list[FID_VALUE] = count
		field_list[FID_TIME] = Time(Time.RESOLUTION_SECOND, seconds_in_day(), 0)

		session.publish("TEST-SYMBOL", field_list)
	session.process()
