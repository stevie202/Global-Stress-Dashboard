TRANSPORT_TYPE_UNDEFINED = 0xff
TRANSPORT_TYPE_UDP_MULTICAST = 0
TRANSPORT_TYPE_UDP_UNICAST = 1
TRANSPORT_TYPE_TCP = 2
TRANSPORT_TYPE_SHARED_MEMORY = 3
TRANSPORT_TYPE_ROUTER_SERVICE = 4

_STRING_MAP = {
	TRANSPORT_TYPE_UDP_MULTICAST: "multicast",
	TRANSPORT_TYPE_UDP_UNICAST: "udp-unicast",
	TRANSPORT_TYPE_TCP: "tcp",
	TRANSPORT_TYPE_SHARED_MEMORY: "shared-memory",
	TRANSPORT_TYPE_ROUTER_SERVICE: "router-service" }

def transport_type_to_string(transport_type):
	if transport_type in _STRING_MAP:
		return _STRING_MAP[transport_type]
	else:
		return f"unknown ({transport_type})"
