TIME_SERIES_TYPE_TICK = 0
TIME_SERIES_TYPE_INTRADAY_BAR = 1
TIME_SERIES_TYPE_HISTORY_BAR = 2

_STRING_MAP = {
	TIME_SERIES_TYPE_TICK:         "tick",
	TIME_SERIES_TYPE_INTRADAY_BAR: "intraday-bar",
	TIME_SERIES_TYPE_HISTORY_BAR:  "history-bar" }

def time_series_type_to_string(time_series_type):
	if time_series_type in _STRING_MAP:
		return _STRING_MAP[time_series_type]
	else:
		return f"unknown ({time_series_type})"
