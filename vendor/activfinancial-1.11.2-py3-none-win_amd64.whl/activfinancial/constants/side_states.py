SIDE_STATE_OK = 0
SIDE_STATE_ABNORMAL = 1
SIDE_STATE_UNAVAILABLE = 2

_STRING_MAP = {
	SIDE_STATE_OK: "ok",
	SIDE_STATE_ABNORMAL: "abnormal",
	SIDE_STATE_UNAVAILABLE: "unavailable" }

def side_state_to_string(side_state):
	if side_state in _STRING_MAP:
		return _STRING_MAP[side_state]
	else:
		return f"unknown ({side_state})"
