# Update an existing topic or create a new topic.
PUBLISH_FLAG_NONE = 0

# Update an existing topic; a new topic will not be created.
PUBLISH_FLAG_DO_NOT_ADD = 0x1

# Delete an existing topic.
PUBLISH_FLAG_DELETE = 0x2
