UPDATE_TYPE_NONE = 0
UPDATE_TYPE_MAP_ADD = 1
UPDATE_TYPE_MAP_UPDATE = 2
UPDATE_TYPE_MAP_REMOVE = 3
UPDATE_TYPE_MAP_COMMON = 4

_STRING_MAP = {
	UPDATE_TYPE_NONE: 'none',
	UPDATE_TYPE_MAP_ADD: 'map-add',
	UPDATE_TYPE_MAP_UPDATE: 'map-update',
	UPDATE_TYPE_MAP_REMOVE:	'map-remove',
	UPDATE_TYPE_MAP_COMMON:	'map-common' }

def update_type_to_string(update_type):
	if update_type in _STRING_MAP:
		return _STRING_MAP[update_type]
	else:
		return f"unknown ({update_type})"
