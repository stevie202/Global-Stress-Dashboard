SUBSCRIPTION_STATE_PENDING = 0
SUBSCRIPTION_STATE_COMPLETE = 1
SUBSCRIPTION_STATE_ERROR = 2
SUBSCRIPTION_STATE_FAILURE = 3

_STRING_MAP = {
	SUBSCRIPTION_STATE_PENDING: "pending",
	SUBSCRIPTION_STATE_COMPLETE: "complete",
	SUBSCRIPTION_STATE_ERROR: "error",
	SUBSCRIPTION_STATE_FAILURE: "failure" }

def subscription_state_to_string(subscription_state):
	if subscription_state in _STRING_MAP:
		return _STRING_MAP[subscription_state]
	else:
		return f"unknown ({subscription_state})"
