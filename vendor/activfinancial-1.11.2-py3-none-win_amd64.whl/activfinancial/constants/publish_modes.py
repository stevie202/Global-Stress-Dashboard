# Disables publishing.
PUBLISH_MODE_DISABLED = 0

# Enables push mode publishing.
PUBLISH_MODE_PUSH = 1
