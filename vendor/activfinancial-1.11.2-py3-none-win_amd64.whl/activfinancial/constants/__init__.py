from .conflation_types import *
from .data_source_ids import *
from .dictionary_ids import *
from .event_types import *
from .field_ids import *
from .field_types import *
from .publish_flags import *
from .publish_modes import *
from .query_states import *
from .log_types import *
from .service_status import *
from .session_states import *
from .side_states import *
from .status_codes import *
from .subscription_states import *
from .symbology_ids import *
from .time_series import *
from .topic_subscription_states import *
from .topic_types import *
from .transport_types import *
from .update_types import *

HANDLE_UNDEFINED = 18446744073709551615

EVENT_TYPE_UNDEFINED = 0xff

CONFLATION_INTERVAL_MIN = 0xffffffff

PERMISSION_ID_NONE = 0
PERMISSION_ID_UNKNOWN = 0xffff

RELATIONSHIP_ID_NONE = 0
RELATIONSHIP_ID_UNDEFINED = 0xff

TABLE_NO_UNDEFINED = 0xffff
