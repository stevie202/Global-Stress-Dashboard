TOPIC_TYPE_FLAT = 0
TOPIC_TYPE_MAP = 1
TOPIC_TYPE_GROUP = 2

_STRING_MAP = {
	TOPIC_TYPE_FLAT: "flat",
	TOPIC_TYPE_MAP: "map",
	TOPIC_TYPE_GROUP: "group" }

def topic_type_to_string(topic_type):
	if topic_type in _STRING_MAP:
		return _STRING_MAP[topic_type]
	else:
		return f"unknown ({topic_type})"
