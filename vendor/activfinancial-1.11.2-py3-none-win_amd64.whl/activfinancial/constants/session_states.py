SESSION_STATE_CONNECTED = 0
SESSION_STATE_W4_CONTROL_CONNECT = 1
SESSION_STATE_W4_LOGIN = 2
SESSION_STATE_W4_SYNC = 3
SESSION_STATE_W4_DATA_CONNECT = 4
SESSION_STATE_W4_SERVICES = 5
SESSION_STATE_W4_DISCONNECT = 6
SESSION_STATE_DISCONNECTED = 7

_STRING_MAP = {
	SESSION_STATE_W4_CONTROL_CONNECT: "w4-control-connect",
	SESSION_STATE_W4_LOGIN:           "w4-login",
	SESSION_STATE_W4_SYNC:            "w4-sync",
	SESSION_STATE_W4_DATA_CONNECT:    "w4-data-connect",
	SESSION_STATE_W4_SERVICES:        "w4-services",
	SESSION_STATE_CONNECTED:          "connected",
	SESSION_STATE_W4_DISCONNECT:      "w4-disconnect",
	SESSION_STATE_DISCONNECTED:       "disconnected" }

def session_state_to_string(session_state):
	if session_state in _STRING_MAP:
		return _STRING_MAP[session_state]
	else:
		return f"unknown ({session_state})"
