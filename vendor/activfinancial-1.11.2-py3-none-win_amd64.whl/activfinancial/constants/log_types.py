LOG_TYPE_DEBUG = 0
LOG_TYPE_INFO = 1
LOG_TYPE_WARNING = 2
LOG_TYPE_ERROR = 3

_STRING_MAP = {
	LOG_TYPE_DEBUG:    "Debug",
	LOG_TYPE_INFO:     "Info",
	LOG_TYPE_WARNING:  "Warning",
	LOG_TYPE_ERROR:    "Error" }

def log_type_to_string(log_type):
	if log_type in _STRING_MAP:
		return _STRING_MAP[log_type]
	else:
		return f"unknown ({log_type})"
