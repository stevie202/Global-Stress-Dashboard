CONFLATION_TYPE_NONE = 0
CONFLATION_TYPE_QUOTE = 1
CONFLATION_TYPE_TOTAL = 2

_STRING_MAP = {
	CONFLATION_TYPE_NONE:  "none",
	CONFLATION_TYPE_QUOTE: "quote",
	CONFLATION_TYPE_TOTAL: "total" }

def conflation_type_to_string(conflation_type):
	if conflation_type in _STRING_MAP:
		return _STRING_MAP[conflation_type]
	else:
		return f"unknown ({conflation_type})"
