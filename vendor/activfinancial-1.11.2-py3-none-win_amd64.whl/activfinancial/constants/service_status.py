SERVICE_STATUS_OFFLINE = 0
SERVICE_STATUS_MAINTENANCE = 1
SERVICE_STATUS_ONLINE = 2
SERVICE_STATUS_STOPPING = 3
SERVICE_STATUS_PARTIALLY_UP = 4
SERVICE_STATUS_DISABLED = 5

_STRING_MAP = {
	SERVICE_STATUS_OFFLINE:  "offline",
	SERVICE_STATUS_MAINTENANCE: "maintenance",
	SERVICE_STATUS_ONLINE: "online",
	SERVICE_STATUS_STOPPING: "stoppping",
	SERVICE_STATUS_PARTIALLY_UP: "partially-up",
	SERVICE_STATUS_DISABLED: "disabled" }

def service_status_to_string(service_status):
	if service_status in _STRING_MAP:
		return _STRING_MAP[service_status]
	else:
		return f"unknown ({service_status})"
