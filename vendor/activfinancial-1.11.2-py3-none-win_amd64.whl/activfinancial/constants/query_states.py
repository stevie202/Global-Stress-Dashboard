QUERY_STATE_PENDING = 0
QUERY_STATE_COMPLETE = 1
QUERY_STATE_ERROR = 2
QUERY_STATE_FAILURE = 3

_STRING_MAP = {
	QUERY_STATE_PENDING: "pending",
	QUERY_STATE_COMPLETE: "complete",
	QUERY_STATE_ERROR: "error",
	QUERY_STATE_FAILURE: "failure" }

def query_state_to_string(query_state):
	if query_state in _STRING_MAP:
		return _STRING_MAP[query_state]
	else:
		return f"unknown ({query_state})"