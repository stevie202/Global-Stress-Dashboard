from ctypes import *

from . import constants
from . import field_types

import ctypes
import datetime
import functools
import glob
import os
import platform

# This file contains structs, functions and load_library().

class C_Timespec(Structure):
	_fields_ = [
		('tv_sec', c_uint64),
		('tv_nsec', c_uint32) ]

	def time(self):
		return self.tv_sec + (self.tv_nsec / 1000000000)

class C_FieldData(Structure):
	_fields_ = [
		('field_id', c_uint16),
		('field_type', c_uint8),
		('does_update_last', c_bool),
		('value', c_void_p) ]

class C_SnapshotMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('permission_id', c_uint16),
		('update_id', c_uint16),
		('is_complete', c_bool),
		('timestamp', POINTER(C_Timespec)),
		('fields', POINTER(C_FieldData)),
		('number_of_fields', c_uint16) ]

class C_SnapshotFailureMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('permission_id', c_uint16),
		('status_code', c_uint8),
		('is_complete', c_bool) ]

class C_RefreshMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('topic_type', c_uint8),
		('permission_id', c_uint16),
		('update_id', c_uint16),
		('map_key_buffer', POINTER(c_uint8)),
		('map_key_length', c_uint8),
		('topic_subscription_state', c_uint8),
		('gateway_timestamp', POINTER(C_Timespec)),
		('api_timestamp', POINTER(C_Timespec)),
		('fields', POINTER(C_FieldData)),
		('number_of_fields', c_uint16) ]

class C_UpdateMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('topic_type', c_uint8),
		('permission_id', c_uint16),
		('update_id', c_uint16),
		('event_type', c_uint8),
		('update_type', c_uint8),
		('map_key_buffer', POINTER(c_uint8)),
		('map_key_length', c_uint8),
		('topic_subscription_state', c_uint8),
		('source_id', POINTER(c_uint32)),
		('sequence_number', POINTER(c_uint64)),
		('exchange_transaction_timestamp', POINTER(C_Timespec)),
		('source_timestamp', POINTER(C_Timespec)),
		('gateway_timestamp', POINTER(C_Timespec)),
		('api_timestamp', POINTER(C_Timespec)),
		('fields', POINTER(C_FieldData)),
		('number_of_fields', c_uint16) ]

class C_TopicStatusMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('topic_type', c_uint8),
		('topic_subscription_state', c_uint8) ]

class C_SubscriptionStatusMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('request', c_char_p),
		('state', c_uint8),
		('status_code', c_uint8) ]

class C_QueryAddMessage(Structure):
	_fields_ = [
		('topic_type', c_uint8),
		('data_source_id', c_uint16),
		('table_number', c_uint16),
		('symbol', c_char_p) ]

class C_QueryRemoveMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbol', c_char_p) ]

class C_QueryStatusMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('query', c_char_p),
		('state', c_uint8),
		('status_code', c_uint8) ]

class C_TimeSeriesMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('permission_id', c_uint16),
		('type', c_int),
		('is_complete', c_bool),
		('fields', POINTER(C_FieldData)),
		('number_of_fields', c_uint16) ]

class C_TimeSeriesFailureMessage(Structure):
	_fields_ = [
		('data_source_id', c_uint16),
		('symbology_id', c_uint16),
		('symbol', c_char_p),
		('permission_id', c_uint16),
		('status_code', c_uint8),
		('is_complete', c_bool) ]

class C_MetadataDataSourceEntry(Structure):
	_fields_ = [
		('id', c_uint16),
		('name', c_char_p),
		('symbology_id', c_uint16),
	    ('dictionary_id', c_uint16) ]

class C_MetadataSymbologyEntry(Structure):
	_fields_ = [
		('id', c_uint16),
		('name', c_char_p) ]

class C_MetadataFieldEntry(Structure):
	_fields_ = [
		('field_id', c_uint16),
		('name', c_char_p),
		('type', c_uint8) ]

class C_MetadataDictionaryEntry(Structure):
	_fields_ = [
		('id', c_uint16),
		('name', c_char_p),
	    ('fields', POINTER(C_MetadataFieldEntry)),
		('field_count', c_uint32) ]

class C_MetadataMessage(Structure):
	_fields_ = [
		('data_sources', POINTER(C_MetadataDataSourceEntry)),
		('data_source_count', c_uint32),
		('symbologies', POINTER(C_MetadataSymbologyEntry)),
		('symbology_count', c_uint32),
		('dictionaries', POINTER(C_MetadataDictionaryEntry)),
		('dictionary_count', c_uint32) ]

# ------------------------------------------------------------------------------

# Field types data.
class C_FieldValueDate(Structure):
	_fields_ = [
		('day', c_uint8),
		('month', c_uint8),
		('year', c_uint16) ]

	def convert(self):
		return datetime.date(self.year, self.month, self.day)

class C_FieldValueTime(Structure):
	_fields_ = [
		('resolution', c_uint8),
		('seconds_in_day', c_uint32),
		('sub_second', c_uint32) ]

	def convert(self):
		return field_types.Time(self.resolution, self.seconds_in_day, self.sub_second)

class C_FieldValueDateTime(Structure):
	_fields_ = [
		('date', C_FieldValueDate),
		('time', C_FieldValueTime) ]

	def convert(self):
		return field_types.DateTime(self.date.convert(), self.time.convert())

class C_FieldValueRational(Structure):
	_fields_ = [
		('denominator', c_int32),
		('numerator', c_int64) ]

	def convert(self):
		return field_types.Rational(self.denominator, self.numerator)

class C_FieldValueTRational(Structure):
	_fields_ = [
		('tick', c_uint8),
		('trend_on_day', c_uint8),
		('rational', C_FieldValueRational) ]

	def convert(self):
		return field_types.TRational(self.tick, self.trend_on_day, self.rational.convert())

class C_FieldValueBuffer(Structure):
	_fields_ = [
		('data', POINTER(c_uint8)),
		('length', c_uint32)]

	def convert_bytes(self):
		return bytes(self.data[0:self.length])

	def convert_str(self):
		return self.convert_bytes().decode()

class C_FieldValueNestedFieldData(Structure):
	_fields_ = [
		('fields', POINTER(C_FieldData)),
		('number_of_fields', c_uint16) ]

	def convert_map(self):
		result = {}
		for i in range(0, self.number_of_fields):
			field = self.fields[i]
			if field.value is not None:
				result[field.field_id] = decode_field_value(field.field_type, field.value)
			else:
				result[field.field_id] = None

		return result

	def convert_list(self):
		result = []
		for i in range(0, self.number_of_fields):
			field = self.fields[i]

			# Note that undefined values are not allowed in FieldTypeList, so
			# field.value should always be != None.
			if field.value is not None:
				result.append(decode_field_value(field.field_type, field.value))
		
		return result

# ------------------------------------------------------------------------------

# Time Series Tick Parameters
class C_TimeSeriesTickParameters(Structure):
	_fields_ = [
		('symbology_id', c_uint16),
		('start', C_FieldValueDateTime),
		('end', C_FieldValueDateTime),
		('count', c_int),
		('should_reverse', c_bool),
		('is_utc', c_bool),
		('filter', c_int) ]

# ------------------------------------------------------------------------------

# Time Series Intraday Bar Parameters
class C_TimeSeriesIntradayBarParameters(Structure):
	_fields_ = [
		('symbology_id', c_uint16),
		('start', C_FieldValueDateTime),
		('end', C_FieldValueDateTime),
		('count', c_int),
		('should_reverse', c_bool),
		('is_utc', c_bool),
		('interval', c_int),
		('filter', c_int)  ]

# ------------------------------------------------------------------------------

# Time Series History Bar Parameters
class C_TimeSeriesHistoryBarParameters(Structure):
	_fields_ = [
		('symbology_id', c_uint16),
		('start', C_FieldValueDate),
		('end', C_FieldValueDate),
		('count', c_int),
		('should_reverse', c_bool),
		('interval', c_int) ]

# ------------------------------------------------------------------------------

C_SessionConnectCallback = CFUNCTYPE(None)
C_SessionDisconnectCallback = CFUNCTYPE(None)
C_SessionErrorCallback = CFUNCTYPE(None, c_uint8)
C_SessionLogMessageCallback = CFUNCTYPE(None, c_uint8, c_char_p)
C_SessionPostTaskCallback = CFUNCTYPE(None)
C_SessionUserMessageCallback = CFUNCTYPE(None, POINTER(c_uint8), c_uint32)
C_SessionUpdateMetadataCallback = CFUNCTYPE(None, POINTER(C_MetadataMessage))
C_SnapshotSuccessCallback = CFUNCTYPE(None, c_uint64, POINTER(C_SnapshotMessage))
C_SnapshotFailureCallback = CFUNCTYPE(None, c_uint64, POINTER(C_SnapshotFailureMessage))
C_SubscriptionRefreshCallback = CFUNCTYPE(None, c_uint64, POINTER(C_RefreshMessage))
C_SubscriptionUpdateCallback = CFUNCTYPE(None, c_uint64, POINTER(C_UpdateMessage))
C_SubscriptionTopicStatusCallback = CFUNCTYPE(None, c_uint64, POINTER(C_TopicStatusMessage))
C_SubscriptionStatusCallback = CFUNCTYPE(None, c_uint64, POINTER(C_SubscriptionStatusMessage))
C_QueryAddCallback = CFUNCTYPE(None, c_uint64, POINTER(C_QueryAddMessage))
C_QueryRemoveCallback = CFUNCTYPE(None, c_uint64, POINTER(C_QueryRemoveMessage))
C_QueryStatusCallback = CFUNCTYPE(None, c_uint64, POINTER(C_QueryStatusMessage))
C_TimeSeriesMessageCallback = CFUNCTYPE(None, c_uint64, POINTER(C_TimeSeriesMessage))
C_TimeSeriesFailureCallback = CFUNCTYPE(None, c_uint64, POINTER(C_TimeSeriesFailureMessage))

# Sync callbacks
C_SyncSnapshotFailureMessageCallback = CFUNCTYPE(None, POINTER(C_SnapshotFailureMessage))
C_SyncSnapshotMessageCallback = CFUNCTYPE(None, POINTER(C_SnapshotMessage))
C_SyncTimeSeriesMessageCallback = CFUNCTYPE(None, POINTER(C_TimeSeriesMessage))

# ------------------------------------------------------------------------------

def decode_field_value(field_type, value):
	# TODO: convert to match-case when we can drop support for python < 3.10
	if field_type == constants.FIELD_TYPE_DATE:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueDate))[0].convert()
	elif field_type == constants.FIELD_TYPE_TIME:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueTime))[0].convert()
	elif field_type == constants.FIELD_TYPE_DATE_TIME:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueDateTime))[0].convert()
	elif field_type == constants.FIELD_TYPE_SINT:
		return ctypes.cast(value, ctypes.POINTER(c_int64))[0]
	elif field_type == constants.FIELD_TYPE_UINT:
		return ctypes.cast(value, ctypes.POINTER(c_uint64))[0]
	elif field_type == constants.FIELD_TYPE_TRATIONAL:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueTRational))[0].convert()
	elif field_type == constants.FIELD_TYPE_RATIONAL:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueRational))[0].convert()

	elif (field_type == constants.FIELD_TYPE_TEXT_ARRAY or
			field_type == constants.FIELD_TYPE_TEXT_STRING):

		return ctypes.cast(value, ctypes.POINTER(C_FieldValueBuffer))[0].convert_str()

	elif (field_type == constants.FIELD_TYPE_BINARY_STRING or
			field_type == constants.FIELD_TYPE_BINARY_ARRAY or
			field_type == constants.FIELD_TYPE_BLOB or
			field_type == constants.FIELD_TYPE_CRC_BLOB):

		return ctypes.cast(value, ctypes.POINTER(C_FieldValueBuffer))[0].convert_bytes()

	elif field_type == constants.FIELD_TYPE_DOUBLE:
		return ctypes.cast(value, ctypes.POINTER(c_double))[0]
	elif field_type == constants.FIELD_TYPE_BOOLEAN:
		return ctypes.cast(value, ctypes.POINTER(c_bool))[0]
	elif field_type == constants.FIELD_TYPE_FIELD_MAP:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueNestedFieldData))[0].convert_map()
	elif field_type == constants.FIELD_TYPE_FIELD_TYPE_LIST:
		return ctypes.cast(value, ctypes.POINTER(C_FieldValueNestedFieldData))[0].convert_list()
	else:
		raise RuntimeError(f'unsupported field type {self.field_type}')

# ------------------------------------------------------------------------------

def init_library(dll_path = None):
	if dll_path is None:
		if 'ACTIV_ONE_API_PATH' in os.environ:
			dll_path = os.environ['ACTIV_ONE_API_PATH']
		else:
			# Assume the module is in the original SDK directory structure.
			dll_path = os.path.join(os.path.dirname(__file__), 'lib')

	# Search path for possible library names.
	filename = None
	for pattern in [ 'ActivOneApi_*_mdi.dll', 'ActivOneApi_*_mdid.dll', 'libActivOneApi_*_mdi.so', 'libActivOneApi_*_mdid.so', 'libActivOneApi_*_mdi.dylib', 'libActivOneApi_*_mdid.dylib' ]:
		files = glob.glob(dll_path + '/' + pattern)
		if len(files) > 0:
			filename = files[0]

	if filename is None:
		raise RuntimeError(f"ActivOneApi library not found in path {dll_path}")

	# This was needed to pick up DLL dependencies.
	if hasattr(os, 'add_dll_directory'):
		os.add_dll_directory(dll_path)

	# And it seems this is needed sometimes too (which might make the line above redundant).
	# It would be nice to debug further to find out what's going on.
	previous_dir = os.getcwd()
	os.chdir(dll_path)

	try:
		# Setup library.
		lib = CDLL(filename)
	except:
		os.chdir(previous_dir)
		raise

	os.chdir(previous_dir)

	lib.activ_exchange_info_init.restype = c_void_p
	lib.activ_exchange_info_init.argtypes = [ c_void_p, c_char_p, c_int64, c_int64, POINTER(C_FieldValueDateTime), POINTER(C_FieldValueDateTime) ]

	lib.activ_session_init.restype = c_void_p
	lib.activ_session_init.argtypes = [
		c_char_p,
		C_SessionConnectCallback,
		C_SessionDisconnectCallback,
		C_SessionErrorCallback,
		C_SessionLogMessageCallback,
		C_SessionPostTaskCallback,
		C_SessionUserMessageCallback,
		C_SessionUpdateMetadataCallback,
		C_SnapshotSuccessCallback,
		C_SnapshotFailureCallback,
		C_SubscriptionRefreshCallback,
		C_SubscriptionUpdateCallback,
		C_SubscriptionTopicStatusCallback,
		C_SubscriptionStatusCallback,
		C_QueryAddCallback,
		C_QueryRemoveCallback,
		C_QueryStatusCallback,
		C_TimeSeriesMessageCallback,
		C_TimeSeriesFailureCallback ]

	lib.activ_session_destroy.restype                           = None
	lib.activ_session_destroy.argtypes                          = [ c_void_p ]
	lib.activ_session_get_parameters.restype                    = c_uint8
	lib.activ_session_get_parameters.argtypes                   = [ c_void_p, POINTER(c_char_p), POINTER(c_char_p), POINTER(c_char_p)]
	lib.activ_session_process.restype                           = c_uint8
	lib.activ_session_process.argtypes                          = [ c_void_p ]
	lib.activ_session_connect.restype                           = c_uint8
	lib.activ_session_connect.argtypes                          = [ c_void_p, c_char_p, c_uint32, POINTER(POINTER(C_MetadataMessage)) ]
	lib.activ_session_async_connect.restype                     = c_uint8
	lib.activ_session_async_connect.argtypes                    = [ c_void_p, c_char_p ]
	lib.activ_session_disconnect.restype                        = c_uint8
	lib.activ_session_disconnect.argtypes                       = [ c_void_p ]
	lib.activ_session_post_user_message.restype                 = c_uint8
	lib.activ_session_post_user_message.argtypes                = [ c_void_p, c_void_p, c_uint32 ]
	lib.activ_session_shutdown.restype                          = c_uint8
	lib.activ_session_shutdown.argtypes                         = [ c_void_p ]
	lib.activ_session_close_handle.restype                      = None
	lib.activ_session_close_handle.argtypes                     = [ c_void_p, c_uint64 ]
	lib.activ_session_register_snapshot_parameters.restype      = c_uint8
	lib.activ_session_register_snapshot_parameters.argtypes     = [ c_void_p, c_char_p, POINTER(c_uint64) ]
	lib.activ_session_snapshot.restype                          = c_uint64
	lib.activ_session_snapshot.argtypes                         = [ c_void_p, c_uint16, c_uint16, c_char_p, c_uint64 ]
	lib.activ_session_sync_snapshot.restype                     = c_uint8
	lib.activ_session_sync_snapshot.argtypes                    = [ c_void_p, c_uint16, c_uint16, c_char_p, c_uint64, c_uint32, POINTER(C_SnapshotMessage) ]
	lib.activ_session_register_subscription_parameters.restype  = c_uint8
	lib.activ_session_register_subscription_parameters.argtypes = [ c_void_p, c_char_p, POINTER(c_uint64) ]
	lib.activ_session_subscribe.restype                         = c_uint64
	lib.activ_session_subscribe.argtypes                        = [ c_void_p, c_uint16, c_uint16, c_char_p, c_uint64 ]
	lib.activ_session_query.restype                             = c_uint64
	lib.activ_session_query.argtypes                            = [ c_void_p, c_uint16, c_char_p ]
	lib.activ_session_sync_query.restype                        = c_uint8
	lib.activ_session_sync_query.argtypes                       = [ c_void_p, c_uint16, c_char_p, c_uint32, POINTER(POINTER(C_QueryAddMessage)), POINTER(c_uint32) ]
	lib.activ_session_publish.restype                           = c_uint8
	lib.activ_session_publish.argtypes                          = [ c_void_p, c_char_p, POINTER(C_FieldData), c_uint32, c_uint16, c_uint16, c_uint8, c_uint8]
	lib.activ_session_get_state.restype                         = c_uint8
	lib.activ_session_get_state.argtypes                        = [ c_void_p ]
	lib.activ_session_query_subscribe.restype					= c_uint64
	lib.activ_session_query_subscribe.argtypes					= [ c_void_p, c_uint16, c_char_p, c_uint64 ]
	lib.activ_session_query_snapshot.restype					= c_uint64
	lib.activ_session_query_snapshot.argtypes					= [ c_void_p, c_uint16, c_char_p, c_uint64 ]
	lib.activ_session_sync_query_snapshot.restype				= c_uint64
	lib.activ_session_sync_query_snapshot.argtypes			    = [ c_void_p, c_uint16, c_char_p, c_uint64, c_uint32, C_SyncSnapshotMessageCallback, C_SyncSnapshotFailureMessageCallback ]
	lib.activ_session_time_series_ticks.restype					= c_uint64
	lib.activ_session_time_series_ticks.argtypes				= [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesTickParameters) ]
	lib.activ_session_time_series_intraday_bars.restype			= c_uint64
	lib.activ_session_time_series_intraday_bars.argtypes		= [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesIntradayBarParameters) ]
	lib.activ_session_time_series_history_bars.restype			= c_uint64
	lib.activ_session_time_series_history_bars.argtypes			= [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesHistoryBarParameters) ]
	lib.activ_session_sync_time_series_ticks.restype			= c_uint64
	lib.activ_session_sync_time_series_ticks.argtypes			= [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesTickParameters), c_uint32, C_SyncTimeSeriesMessageCallback ]
	lib.activ_session_sync_time_series_intraday_bars.restype	= c_uint64
	lib.activ_session_sync_time_series_intraday_bars.argtypes	= [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesIntradayBarParameters), c_uint32, C_SyncTimeSeriesMessageCallback ]
	lib.activ_session_sync_time_series_history_bars.restype		= c_uint64
	lib.activ_session_sync_time_series_history_bars.argtypes    = [ c_void_p, c_uint16, c_char_p, POINTER(C_TimeSeriesHistoryBarParameters), c_uint32, C_SyncTimeSeriesMessageCallback ]
	lib.activ_session_post_task.restype							= c_uint8
	lib.activ_session_post_task.argtypes						= [ c_void_p ]
	lib.activ_exchange_info_convert_date_time_to_utc.restype	= c_uint8
	lib.activ_exchange_info_convert_date_time_to_utc.argtypes	= [ c_void_p, POINTER(C_FieldValueDate), POINTER(C_FieldValueTime), POINTER(C_FieldValueDateTime) ]
	lib.activ_session_get_error_string.restype					= c_char_p
	lib.activ_session_get_error_string.argtypes					= [ c_void_p ]

	return lib
