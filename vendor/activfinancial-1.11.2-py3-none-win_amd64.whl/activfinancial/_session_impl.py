from ._c_lib import *
from ._utils import *
from .utils import *
from .types import *
from . import constants

import traceback
import weakref

class SessionImpl:
	def __init__(self, session, parameters, handler, dll_path):
		self.session_ref = weakref.ref(session)
		self.handler = handler
		self.handler_map = {}		# Map from handle to user handlers.
		self.task_queue = []

		self.lib = init_library(dll_path)
		self.setup_callbacks()

		# Create the underlying session.
		self.session_context = self.lib.activ_session_init(
			DictToFieldMapString(parameters).encode(),
			self.callback_session_connect,
			self.callback_session_disconnect,
			self.callback_session_error,
			self.callback_session_log_message,
			self.callback_session_process_task,
			self.callback_session_user_message,
			self.callback_session_update_metadata,
			self.callback_snapshot_success,
			self.callback_snapshot_failure,
			self.callback_subscription_refresh,
			self.callback_subscription_update,
			self.callback_subscription_topic_status,
			self.callback_subscription_status,
			self.callback_query_add,
			self.callback_query_remove,
			self.callback_query_status,
			self.callback_time_series_message,
			self.callback_time_series_failure)

		if self.session_context is None:
			raise RuntimeError('failed to create session context')

	def __del__(self):
		if hasattr(self, 'session_context'):
			self.lib.activ_session_destroy(self.session_context)
			del self.session_context

	def setup_callbacks(self):
		# Setup callbacks, store them so that they don't get garbage collected.
		r = weakref.ref(self)

		self.callback_session_connect         = C_SessionConnectCallback       (lambda : SessionImpl.on_session_connect(r))
		self.callback_session_disconnect      = C_SessionDisconnectCallback    (lambda : SessionImpl.on_session_disconnect(r))
		self.callback_session_error           = C_SessionErrorCallback         (lambda a: SessionImpl.on_session_error(r, a))
		self.callback_session_log_message     = C_SessionLogMessageCallback    (lambda a, b: SessionImpl.on_session_log_message(r, a, b))
		self.callback_session_process_task    = C_SessionPostTaskCallback      (lambda : SessionImpl.process_task(r))
		self.callback_session_user_message    = C_SessionUserMessageCallback   (lambda a, b: SessionImpl.on_session_user_message(r, a, b))
		self.callback_session_update_metadata = C_SessionUpdateMetadataCallback(lambda a: SessionImpl.on_session_update_metadata(r, a))

		self.callback_snapshot_success = C_SnapshotSuccessCallback(lambda a, b: SessionImpl.on_snapshot_success(r, a, b))
		self.callback_snapshot_failure = C_SnapshotFailureCallback(lambda a, b: SessionImpl.on_snapshot_failure(r, a, b))

		self.callback_subscription_refresh      = C_SubscriptionRefreshCallback    (lambda a, b: SessionImpl.on_subscription_refresh(r, a, b))
		self.callback_subscription_update       = C_SubscriptionUpdateCallback     (lambda a, b: SessionImpl.on_subscription_update(r, a, b))
		self.callback_subscription_topic_status = C_SubscriptionTopicStatusCallback(lambda a, b: SessionImpl.on_subscription_topic_status(r, a, b))
		self.callback_subscription_status       = C_SubscriptionStatusCallback     (lambda a, b: SessionImpl.on_subscription_status(r, a, b))

		self.callback_query_add    = C_QueryAddCallback    (lambda a, b: SessionImpl.on_query_add(r, a, b))
		self.callback_query_remove = C_QueryRemoveCallback (lambda a, b: SessionImpl.on_query_remove(r, a, b))
		self.callback_query_status = C_QueryStatusCallback (lambda a, b: SessionImpl.on_query_status(r, a, b))

		self.callback_time_series_message = C_TimeSeriesMessageCallback (lambda a, b: SessionImpl.on_time_series_message(r, a, b))
		self.callback_time_series_failure = C_TimeSeriesFailureCallback (lambda a, b: SessionImpl.on_time_series_failure(r, a, b))

	@classmethod
	def on_session_connect(cls, ref):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		try:
			session._check_publish_mode()
		except Exception as e:
			if hasattr(impl.handler, 'on_session_log_message'):
				impl.handler.on_session_log_message(session, constants.LOG_TYPE_ERROR, str(e))

		if hasattr(impl.handler, 'on_session_connect'):
			impl.handler.on_session_connect(session)

	@classmethod
	def on_session_disconnect(cls, ref):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if hasattr(impl.handler, 'on_session_disconnect'):
			impl.handler.on_session_disconnect(session)

	@classmethod
	def on_session_error(cls, ref, status_code):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if hasattr(impl.handler, 'on_session_error'):
			impl.handler.on_session_error(session, status_code)

	@classmethod
	def on_session_log_message(cls, ref, log_type, message):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if hasattr(impl.handler, 'on_session_log_message'):
			impl.handler.on_session_log_message(session, log_type, message.decode())

	@classmethod
	def on_session_user_message(cls, ref, data_buffer, length):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if hasattr(impl.handler, 'on_session_user_message'):
			if length > 0:
				message = bytes(data_buffer[0:length])
			else:
				message = bytes()

			impl.handler.on_session_user_message(session, message)

	@classmethod
	def on_session_update_metadata(cls, ref, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		try:
			session.metadata._update(msg_pointer[0])
		except Exception as e:
			impl.handle_callback_exception('on_session_update_metadata', e)

	@classmethod
	def on_snapshot_success(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			fields = {}
			for i in range(0, msg.number_of_fields):
				field = msg.fields[i]
				fields[field.field_id] = Field(field.value, field.field_type, field.does_update_last)

			(handler, user_data) = impl.handler_map[handle]

			handler.on_snapshot(SnapshotMessage(msg, fields), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_snapshot_success', e)

	@classmethod
	def on_snapshot_failure(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_snapshot_failure(SnapshotFailureMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_snapshot_failure', e)

	@classmethod
	def on_subscription_refresh(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			fields = impl.get_fields_from_msg(msg)
			handler.on_subscription_refresh(RefreshMessage(msg, fields), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_subscription_refresh', e)

	@classmethod
	def on_subscription_update(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			fields = impl.get_fields_from_msg(msg)
			handler.on_subscription_update(UpdateMessage(msg, fields), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_subscription_update', e)

	@classmethod
	def on_subscription_topic_status(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_subscription_topic_status(TopicStatusMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_subscription_topic_status', e)

	@classmethod
	def on_subscription_status(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_subscription_status(SubscriptionStatusMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_subscription_status', e)

	@classmethod
	def on_query_add(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_query_add(QueryAddMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_query_add', e)

	@classmethod
	def on_query_remove(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_query_remove(QueryRemoveMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_query_remove', e)

	@classmethod
	def on_query_status(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_query_status(QueryStatusMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_query_status', e)

	@classmethod
	def on_time_series_message(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			fields = impl.get_fields_from_msg(msg)
			handler.on_time_series_message(TimeSeriesMessage(msg, fields), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_time_series_message', e)

	@classmethod
	def on_time_series_failure(cls, ref, handle, msg_pointer):
		impl = ref()
		session = None if impl is None else impl.session_ref()
		if session is None:
			return
		
		if handle not in impl.handler_map:
			return

		msg = msg_pointer[0]

		try:
			(handler, user_data) = impl.handler_map[handle]

			handler.on_time_series_failure(TimeSeriesFailureMessage(msg), Context(session, handle, user_data))
		except Exception as e:
			impl.handle_callback_exception('on_time_series_failure', e)

	def get_fields_from_msg(self, msg):
		fields = {}
		for i in range(0, msg.number_of_fields):
			field = msg.fields[i]
			fields[field.field_id] = Field(field.value, field.field_type, field.does_update_last)
		return fields
	
	def sync_snapshot_message_callback(self, msg_list, msg_pointer):
		msg = msg_pointer[0]

		try:
			fields = self.get_fields_from_msg(msg)
			msg_list.append(types.SnapshotMessage(msg, fields))
		except Exception as e:
			self.handle_callback_exception('internal snapshot', e)
	
	def sync_snapshot_failure_message_callback(self, msg_list, msg_pointer):
		msg = msg_pointer[0]

		try:
			msg_list.append(types.SnapshotFailureMessage(msg))
		except Exception as e:
			self.handle_callback_exception('internal snapshot failure', e)
	
	def time_series_sync_message_callback(self, msg_list, msg_pointer):
		msg = msg_pointer[0]

		try:
			fields = self.get_fields_from_msg(msg)
			msg_list.append(types.TimeSeriesMessage(msg, fields))
		except Exception as e:
			self.handle_callback_exception('internal sync time series', e)

	def handle_callback_exception(self, function, e):
		session = self.session_ref()
		if session is None:
			return
		
		error = f'EXCEPTION processing {function} callback ...\n{traceback.format_exc()}'
		if hasattr(self.handler, 'on_session_log_message'):
			self.handler.on_session_log_message(session, constants.LOG_TYPE_ERROR, error)

	@classmethod
	def process_task(cls, ref):
		impl = ref()

		if impl is None:
			return

		task = impl.task_queue.pop(0)

		if not task:
			RuntimeError("failed to post task - no task to process")

		task()
